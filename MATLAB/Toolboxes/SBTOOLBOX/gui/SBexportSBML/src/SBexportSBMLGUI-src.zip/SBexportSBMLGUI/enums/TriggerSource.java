package SBexportSBMLGUI.enums;

public enum TriggerSource {
	
	SBM_NOTES("SBmodel Notes"),
	NOTES("Notes"),
	ODE_RHS("ODE RHS"),
	FORMULA("Formula"),
	ARGUMENTS("Arguments"),
	TRIGGER("Trigger"),
	ASSIGNMENT("Assignment");
	
	private String textAreaTrigger;
	
	private TriggerSource(String textAreaTrigger) {
		this.textAreaTrigger = textAreaTrigger;
	}
	
	public String toString() {
		return textAreaTrigger;
	}

}
