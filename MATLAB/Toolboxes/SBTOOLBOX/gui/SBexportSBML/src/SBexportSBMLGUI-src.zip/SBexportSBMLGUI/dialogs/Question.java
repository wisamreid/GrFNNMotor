package SBexportSBMLGUI.dialogs;
/**************************************************************************
 * HelpJTextAreaJDialog: Opens a JDialog frame and prints a help text
 *                       dependend on the choosen Menu ITem from 
 *                       GUIJMenuBar-
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import auxiliary.javamodel.SBmodelJava;
import auxiliary.javamodel.SBmodelTools;
import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.DecisionMessage;
import SBexportSBMLGUI.enums.InfoMessage;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Question extends JDialog implements ActionListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 11);
	private JButton yesButton, noButton;
	
	private static final int dialogWidth = 400;
	private static final int dialogHeight = 200;
	
	private SB2SBMLGUI owner;
	private SBmodelJava sbmj;
	
	public Question(SB2SBMLGUI owner, DecisionMessage message, SBmodelJava sbmj) {
		
		super(owner, null, false);
		
		setTitle("Question");
		this.owner = owner;
		this.sbmj = sbmj;
		
		setSize(dialogWidth, dialogHeight);
		setLocation(300,300);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		JTextArea messageArea = new JTextArea();
		messageArea.setEditable(false);
		messageArea.setOpaque(false);
		messageArea.setLineWrap(true);
		messageArea.setWrapStyleWord(true);
		messageArea.setText(message.toString());
		messageArea.setBounds(20, 20, dialogWidth-40, dialogHeight-40);
		messageArea.setFont(font);
		panel.add(messageArea);
		panel.setBounds(0, 0, dialogWidth-20, dialogHeight-20);
		
		panel.add(messageArea);
		
		cp.add("Center", panel);
		
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		yesButton = new JButton("Yes");
		yesButton.addActionListener(this);
		buttonPanel.add(yesButton);
		noButton = new JButton("No");
		noButton.addActionListener(this);
		buttonPanel.add(noButton);
		
		cp.add("South", buttonPanel);
		
	}
	
	public void actionPerformed(ActionEvent event) {
		JButton source = (JButton)event.getSource();
		if (source == yesButton) {
			SBmodelTools.addDefaultCompartment(sbmj);
			
			sbmj.makeCompartmentList();
			owner.updateTab(SBmodelContextType.STATE);
			owner.updateTab(SBmodelContextType.PARAMETER);
			owner.updateTab(SBmodelContextType.VARIABLE);
			JDialog dialog = new Warning(owner, InfoMessage.DEFAULT_COMPARTMENT_ADDED);
			dialog.setVisible(true);
			this.setVisible(false);
			this.dispose();
		} else if (source == noButton) {
			this.setVisible(false);
			this.dispose();
		}
	}
	
}
