package SBexportSBMLGUI.tabs;

/**************************************************************************
 * StatesJPanel: creates a JPanel containing all adjustable elements
 *               that are needed to help to convert the SBmodel
 *               States to fit into a SBML file.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class StatesJPanel extends SBmodelGenericJPanel {
	
	private GridBagLayout gbl;
	private GridBagConstraints gbc;
		
	public StatesJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.STATE);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		
		gbl = new GridBagLayout();
		setLayout(gbl);
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no states print Message!
		 */
		if (sbmj.getNumberOfStates()==0) {
			setLayout(new FlowLayout());
			JLabel noStates = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no states.");
			noStates.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noStates);
		} else {
			/*
			 * SBmodel contains states!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel states!
			 */
			// leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel stateName = new ColumnHeadJPanel("State Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(stateName, gbc);
			add(stateName);
			
			ColumnHeadJPanel odeRHS = new ColumnHeadJPanel("ODE RHS");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(odeRHS, gbc);
			add(odeRHS);
			
			ColumnHeadJPanel iniCond = new ColumnHeadJPanel("Initial Condition");
			gbc = setGBC(4, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(iniCond, gbc);
			add(iniCond);
			
			ColumnHeadJPanel stateType = new ColumnHeadJPanel("SBML Type");
			gbc = setGBC(5, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(stateType, gbc);
			add(stateType);
			
			ColumnHeadJPanel specieUnitType = new ColumnHeadJPanel("Unit Type");
			gbc = setGBC(8, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(specieUnitType, gbc);
			add(specieUnitType);
			
			ColumnHeadJPanel stateCompartment = new ColumnHeadJPanel("Compartment");
			gbc = setGBC(11, 0, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(stateCompartment, gbc);
			add(stateCompartment);
			
			ColumnHeadJPanel stateNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(14, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(stateNotes, gbc);
			add(stateNotes);
		}
		
		/* 
		 * Place all items for each SBmodel state in one row (repeat for all states).
		 * 1. JLabel State Name
		 * 2. JButton ODE RHS calls JDialog with non-editable JTextArea for ODE
		 * 3. JTextField Initial Condition
		 * 4. JComboBox SBML Type (choose specie, parameter, variable or compartment)
		 * 5. JComboBox Unit Type (if SBML Type -> specie : choose amount or concentration
		 * 6. JComboBox Compartment (choose to which compartment the state belongs)
		 * 7. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int statescount=sbmj.getNumberOfStates();
		for (int i=0; i<statescount; i++) {
			int stateIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(stateIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getState(stateIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
			
			GenericJButtonJPanel odeRHSJB = new GenericJButtonJPanel(stateIndex, TriggerSource.ODE_RHS);  
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(odeRHSJB, gbc);
			add(odeRHSJB);
						
			ComponentValueJPanel iniCondJP = new ComponentValueJPanel(stateIndex, sbmj.getState(stateIndex).getInitialCondition());
			gbc = setGBC(4, gridy, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(iniCondJP, gbc);
			add(iniCondJP);
			
			/*
			 * Create the JComboBoxes for the choice of the unit type first and then for
			 * the SBML type, afterards add them to the JPanel.
			 * This is necessary because the functionality of the unit type JComboBox changes
			 * accordingly to the selected item of the SBML type JComboBox.
			 * So we have to provide the instances of unit type JPanel and unit type ItemListener
			 * to SBML type JPanel!
			 */
			UnitTypeJPanel unitTypeJP = new UnitTypeJPanel(stateIndex, sbmj.getState(stateIndex).getUnitType(), sbmj.getState(stateIndex).getType());
			gbc = setGBC(8, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(unitTypeJP, gbc);
			add(unitTypeJP);
			
			CompartmentJPanel compartmentJP = new CompartmentJPanel(stateIndex, sbmj.getState(stateIndex).getName(), sbmj.getState(stateIndex).getCompartment(), sbmj.getState(stateIndex).getType(), sbmj.getCompartments());
			gbc = setGBC(11, gridy, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(compartmentJP, gbc);
			add(compartmentJP);
			
			SBMLTypeJPanel sbmlTypeJP = new SBMLTypeJPanel(stateIndex, sbmj.getState(stateIndex).getType(), unitTypeJP, compartmentJP);
			gbc = setGBC(5, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(sbmlTypeJP, gbc);
			add(sbmlTypeJP);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(stateIndex, TriggerSource.NOTES);  
			gbc = setGBC(14, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
	
}
