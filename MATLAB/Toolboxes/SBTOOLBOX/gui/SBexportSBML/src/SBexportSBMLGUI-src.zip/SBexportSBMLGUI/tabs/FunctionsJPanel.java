package SBexportSBMLGUI.tabs;

/**************************************************************************
 * FunctionsJPanel: creates a JPanel containing all adjustable elements
 *                  that are needed to help to convert the SBmodel
 *                  Functions to fit into a SBML file.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class FunctionsJPanel extends SBmodelGenericJPanel {
		
	GridBagLayout gbl;
	GridBagConstraints gbc;
	
	public FunctionsJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.FUNCTION);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no functions print Message!
		 */
		if (sbmj.getNumberOfFunctions()==0) {
			setLayout(new FlowLayout());
			JLabel noFunctions = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no functions.");
			noFunctions.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noFunctions);
		} else {
			/*
			 * SBmodel contains functions!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel functions!
			 */
			gbl = new GridBagLayout();
			setLayout(gbl);
			
//			 leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel functionName = new ColumnHeadJPanel("Function Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(functionName, gbc);
			add(functionName);
			
			ColumnHeadJPanel arguments = new ColumnHeadJPanel("Arguments");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(arguments, gbc);
			add(arguments);
			
			ColumnHeadJPanel formula = new ColumnHeadJPanel("Formula");
			gbc = setGBC(4, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(formula, gbc);
			add(formula);
			
			ColumnHeadJPanel functionNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(5, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(functionNotes, gbc);
			add(functionNotes);
		}
		
		/* 
		 * Place all items for each SBmodel function in one row (repeat for all functions).
		 * 1. JLabel Function Name
		 * 2. JButton Arguments calls JDialog with editable JTextArea for arguments  
		 * 3. JButton Formula calls JDialog with editable JTextArea for formulas
		 * 4. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int functionscount=sbmj.getNumberOfFunctions();
		for (int i=0; i<functionscount; i++) {
			int functionIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(functionIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getFunction(functionIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
			
			GenericJButtonJPanel argumentsJB = new GenericJButtonJPanel(functionIndex, TriggerSource.ARGUMENTS);  
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(argumentsJB, gbc);
			add(argumentsJB);
			
			GenericJButtonJPanel formulaJB = new GenericJButtonJPanel(functionIndex, TriggerSource.FORMULA);  
			gbc = setGBC(4, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(formulaJB, gbc);
			add(formulaJB);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(functionIndex, TriggerSource.NOTES);  
			gbc = setGBC(5, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
	
}
