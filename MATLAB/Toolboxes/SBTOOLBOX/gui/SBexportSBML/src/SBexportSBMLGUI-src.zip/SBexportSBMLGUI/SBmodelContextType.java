package SBexportSBMLGUI;

public enum SBmodelContextType {
	
	STATE("State"),
	PARAMETER("Parameter"),
	VARIABLE("Variable"),
	REACTION("Reaction"),
	EVENT("Event"),
	FUNCTION("Function");
	
	private String sbModelContext;
	
	private SBmodelContextType(String sbModelContext) {
		this.sbModelContext = sbModelContext;
	}
	
	public static SBmodelContextType toEnum(int ordinal) {
		switch(ordinal) {
		case 0 : return STATE;
		case 1 : return PARAMETER;
		case 2 : return VARIABLE;
		case 3 : return REACTION;
		case 4 : return EVENT;
		case 5 : return FUNCTION;
		}
		return STATE;
	}
	
	public String toString() {
		return sbModelContext;
	}

}
