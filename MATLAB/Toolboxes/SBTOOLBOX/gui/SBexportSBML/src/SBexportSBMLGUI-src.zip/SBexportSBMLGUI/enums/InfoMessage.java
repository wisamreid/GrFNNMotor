package SBexportSBMLGUI.enums;

public enum InfoMessage {
	
	/*
	 * Messages with OK button.
	 */
	BAD_NAME("The name you typed is doesn't fulfil the requirements for the SBmodel.\n" +
					"Permitted are following characters: \"A..Z\", \"a..z\", \"0..9\" and \"_\" (first character may NOT be a digit).\n"+
					"Please correct that!"),
					
	DEFAULT_COMPARTMENT_ADDED("A default compartment has been added! Please check your model " +
					"and click the Export SBML button again."),
	
	NAME_COLLISION("The name you typed is already used wihtin the SBmodel.\n" +
					"Please use another!"),
					
	NO_COMPARTMENT_SELECTED_STATE("In the States Tab there are components of type SBML SPECIE without defined compartment.\n"+
					"Please correct that for SBML export!"),
	
	NO_COMPARTMENT_SELECTED_PARAMETER("In the Parameters Tab there are components of type SBML SPECIE without defined compartment.\n"+
					"Please correct that for SBML export!"),
	
	NO_COMPARTMENT_SELECTED_VARIABLE("In the Variables Tab there are components of type SBML SPECIE without defined compartment.\n"+
					"Please correct that for SBML export!"),
					
	NO_SELECTION_FOR_REMOVE_ASSIGNMENT("No assignment choosen for removing. Please click on the table " +
					"row of the assignment you want to remove!"),
	
	NO_SELECTION_FOR_REMOVE_COMPONENT("No component choosen for removing. Please use the left" +
					"hand side check boxes to choose the component you want to remove!"),
	
	NO_SELECTION_FOR_RENAME_COMPONENT("No component choosen for renaming. Please use the left" +
					"hand side check boxes to choose the component you want to rename!"),
	
	NO_ROOT_COMPARTMENT("There is no root compartment defined in your model!\n\n" +
					"In the current case you may have constructed a loop through assigning the compartment ComboBoxes " + 
					"in the tabs of SBmodel States, Parameters or Variables! Please check and correct the situation, " + 
					"so that there exists only one SBML Compartment with an empty compartment assignment (ComboBox)!"),
					
	LOOP_IN_COMPARTMENTS("A loop has been detected within the compartment definitions!\n" + 
					"Please check the following list and correct the compartment fields.");
	
	private String infoMessage;
	
	private InfoMessage(String infoMessage) {
		this.infoMessage = infoMessage;
	}
	
	public String toString() {
		return infoMessage;
	}

}
