package SBexportSBMLGUI;

/**************************************************************************
 * SBmodelGenericJPanel: serves as abstract JPanel from which all other
 *                       tab panels of the gui are extended.
 *                       Late binding capabilities and some other methods
 *                       which are not overwritten by other classes
 *                       are achieved.
 * 
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import auxiliary.javamodel.SBmodelEvent;
import auxiliary.javamodel.SBmodelJava;

public class SBmodelGenericJPanel extends JPanel {
	
	private SBmodelContextType sbmContext;
	
	protected SBmodelJava sbmj;
	protected ArrayList<JCheckBox> selectionCheckBoxes;
	
//	public SBmodelJava getSBmodelJava() {
//		return sbmj;
//	}
	
	public void initializeSelectionCheckBoxes() {
		selectionCheckBoxes = new ArrayList<JCheckBox>();
		int count = 0;
		switch(sbmContext) {
		case STATE : count = sbmj.getNumberOfStates(); break;
		case PARAMETER : count = sbmj.getNumberOfParameters(); break;
		case VARIABLE : count = sbmj.getNumberOfVariables(); break;
		case REACTION : count = sbmj.getNumberOfReactions(); break;
		case EVENT : count = sbmj.getNumberOfEvents(); break;
		case FUNCTION : count = sbmj.getNumberOfFunctions(); break;
		}
		for (int i=0; i<count; i++) {
			selectionCheckBoxes.add(new JCheckBox());
		}
	}
	
	public List<Integer> getSelectedComponentIndices() {
		ArrayList<Integer> selectedIndices = new ArrayList<Integer>();
		Integer counter = 0;
		for (JCheckBox selectionCB : selectionCheckBoxes) {
			if (selectionCB.isSelected()) selectedIndices.add(counter++);
			else counter++;
		}
		return selectedIndices;
	}
	
	/*
	 * The JComboBox list, the Index and the 4 methods are used 
	 * to have easy access possiblities to all compartment JCBs.
	 *  Because their content has to be changable.
	 */
	private static ArrayList<JComboBox> compartmentList;
	
	public void setNumberOfComparmentJCBs(int count) {
		compartmentList = new ArrayList<JComboBox>(count);
		for (int i=0; i<count; i++) {
			compartmentList.add(new JComboBox());
		}
	}
	
	public void addCompartmentJCBToList(JComboBox compartmentJCB) {
		compartmentList.add(compartmentJCB);
	}
	
	public void addItemToCompartmentJCBs(String addItem) {
		for (JComboBox comboBox : compartmentList) {
			comboBox.addItem(addItem);
		}
	}
	
	public void removeItemFromCompartmentJCBs(String removeItem) {
		for (JComboBox comboBox : compartmentList) {
			comboBox.removeItem(removeItem);
		}
	}
	
	public void selectItemAtCompartmentJCBs() {
		for (JComboBox comboBox : compartmentList) {
			comboBox.setSelectedIndex(0);
		}
	}
	
	/*
	 * A method helping to place a JPanel component to another JPanel which uses 
	 * the GridBagLayout layout manager.
	 */
	public GridBagConstraints setGBC(int x, int y, int width, int height, int fill) {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.gridwidth = width;
		gbc.gridheight = height;
		gbc.anchor = GridBagConstraints.CENTER;
		gbc.insets = new Insets(1, 15, 1, 1);
		return gbc;
	}
	
	/*
	 * Following methods are patterns for the specific classes which are called in
	 * case of late binding and accessing components of the SBmodelJava.
	 * So the additional information wether we have to access a state, parameter,...
	 * is implicit there.
	 */
	
	public List<String> getCompartmentList() {
		return sbmj.getCompartments();
	}
	
	public int makeCompartmentList() {
		return sbmj.makeCompartmentList();
	}
	
	public void printCurrentItem(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			System.out.print("State no."+(index+1)+" (name \""+sbmj.getState(index).getName()+"\"): ");
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			System.out.print("Parameter no."+(index+1)+" (name \""+sbmj.getParameter(index).getName()+"\"): ");
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			System.out.print("Variable no."+(index+1)+" (name \""+sbmj.getVariable(index).getName()+"\"): ");
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			System.out.print("Reaction no."+(index+1)+" (name \""+sbmj.getReaction(index).getName()+"\"): ");
		} else if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			System.out.print("Event no."+(index+1)+" (name \""+sbmj.getEvent(index).getName()+"\"): ");
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			System.out.print("Function no."+(index+1)+" (name \""+sbmj.getFunction(index).getName()+"\"): ");
		} else {
			System.out.println("\nERROR: Wrong context found for printing current item!!!\n");
		}			
	}
	
	public String getCurrentItem(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			return sbmj.getState(index).getName()+" (state no."+(index+1)+")";
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			return sbmj.getParameter(index).getName()+" (parameter no."+(index+1)+")";
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			return sbmj.getVariable(index).getName()+" (variable no."+(index+1)+")";
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			return sbmj.getReaction(index).getName()+" (reaction no."+(index+1)+")";
		} else if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index).getName()+" (event no."+(index+1)+")";
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			return sbmj.getFunction(index).getName()+" (function no."+(index+1)+")";
		} else {
			System.out.println("\nERROR: Wrong context found for getting current item!!!\n");
		}
		return "";
	}
	
	public String getName(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			return sbmj.getState(index).getName();
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			return sbmj.getParameter(index).getName();
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			return sbmj.getVariable(index).getName();
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			return sbmj.getReaction(index).getName();
		} else if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index).getName();
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			return sbmj.getFunction(index).getName();
		} else {
			System.out.println("\nERROR: Wrong context found for getting Name!!!\n");
		}
		return "";
	}
	
	public String getODE(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			return sbmj.getState(index).getODE();
		} else {
			System.out.println("\nERROR: Wrong context found for getting ODE!!!\n");
		}
		return "";
	}
	
	public void setODE(int index, String ode) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setODE(ode);
		} else {
			System.out.println("\nERROR: Wrong context found for setting ODE!!!\n");
		}
	}
	
	public double getValue(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			return sbmj.getState(index).getInitialCondition();
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			return sbmj.getParameter(index).getValue();
		} else {
			System.out.println("\nERROR: Wrong context found for getting value!!!\n");
		}
		return 0;
	}
	
	public void setValue(int index, double value) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setInitialCondition(value);
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			sbmj.getParameter(index).setValue(value);
		} else {
			System.out.println("\nERROR: Wrong context found for setting value!!!\n");
		}
	}
	
	public String getFormula(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			return sbmj.getVariable(index).getFormula();
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			return sbmj.getReaction(index).getFormula();
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			return sbmj.getFunction(index).getFormula();
		} else {
			System.out.println("\nERROR: Wrong context found for getting formula!!!\n");
		}
		return "";
	}
	
	public void setFormula(int index, String formula) {
		if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			sbmj.getVariable(index).setFormula(formula);
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			sbmj.getReaction(index).setFormula(formula);
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			sbmj.getFunction(index).setFormula(formula);
		} else {
			System.out.println("\nERROR: Wrong context found for setting formula!!!\n");
		}
	}
	
	public void setArguments(int index, String arguments) {
		if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			sbmj.getFunction(index).setArguments(arguments);
		} else {
			System.out.println("\nERROR: Wrong context found for setting arguments!!!\n");
		}
	}
	
	public String getArguments(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			return sbmj.getFunction(index).getArguments();
		} else {
			System.out.println("\nERROR: Wrong context found for getting arguments!!!\n");
		}
		return "";
	}
	
	public void setTrigger(int index, String trigger) {
		if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			sbmj.getEvent(index).setTrigger(trigger);
		} else {
			System.out.println("\nERROR: Wrong context found for setting trigger!!!\n");
		}
	}
	
	public String getTrigger(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index).getTrigger();
		} else {
			System.out.println("\nERROR: Wrong context found for getting trigger!!!\n");
		}
		return "";
	}
	
	public SBmodelEvent getEvent(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index);
		} else {
			System.out.println("\nERROR: Wrong context found for getting event!!!\n");
		}
		return null;
	}
	
	public Object[][] getEventAssignmentArray(int index) {
		Object[][] array = new Object[0][0];
		if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index).getEventAssignmentArray();
		} else {
			System.out.println("\nERROR: Wrong context found for getting event assignment!!!\n");
		}
		return array;
	}
	
	public void setEventAssignmentArray(int index, Object[][] array) {
		if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			sbmj.getEvent(index).setEventAssignmentArray(array);
		} else {
			System.out.println("\nERROR: Wrong context found for setting event assignment!!!\n");
		}
	}
	
	public void setSBMLType(int index, String sbmltype) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setType(sbmltype);
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			sbmj.getParameter(index).setType(sbmltype);
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			sbmj.getVariable(index).setType(sbmltype);
		} else {
			System.out.println("\nERROR: Wrong context found for setting SBML type!!!\n");
		}
	}
	
	public void setUnitType(int index, String unittype) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setUnitType(unittype);
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			sbmj.getParameter(index).setUnitType(unittype);
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			sbmj.getVariable(index).setUnitType(unittype);
		} else {
			System.out.println("\nERROR: Wrong context found for setting unit type!!!\n");
		}
	}
	
	public void setCompartment(int index, String compartment) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setCompartment(compartment);
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			sbmj.getParameter(index).setCompartment(compartment);
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			sbmj.getVariable(index).setCompartment(compartment);
		} else {
			System.out.println("\nERROR: Wrong context found for setting compartment!!!\n");
		}
	}
	
	public void setReversible(int index, double value) {
		if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			sbmj.getReaction(index).setReversible(value);
		} else {
			System.out.println("\nERROR: Wrong context found for setting reaction reversible!!!\n");
		}
	}
	
	public String getNotes(int index) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			return sbmj.getState(index).getNotes();
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			return sbmj.getParameter(index).getNotes();
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			return sbmj.getVariable(index).getNotes();
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			return sbmj.getReaction(index).getNotes();
		} else if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			return sbmj.getEvent(index).getNotes();
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			return sbmj.getFunction(index).getNotes();
		} else {
			System.out.println("\nERROR: Wrong context found for getting notes!!!\n");
		}
		return "";
	}
	
	public void setNotes(int index, String notes) {
		if (getSBmodelContext().equals(SBmodelContextType.STATE)) {
			sbmj.getState(index).setNotes(notes);
		} else if (getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
			sbmj.getParameter(index).setNotes(notes);
		} else if (getSBmodelContext().equals(SBmodelContextType.VARIABLE)) {
			sbmj.getVariable(index).setNotes(notes);
		} else if (getSBmodelContext().equals(SBmodelContextType.REACTION)) {
			sbmj.getReaction(index).setNotes(notes);
		} else if (getSBmodelContext().equals(SBmodelContextType.EVENT)) {
			sbmj.getEvent(index).setNotes(notes);
		} else if (getSBmodelContext().equals(SBmodelContextType.FUNCTION)) {
			sbmj.getFunction(index).setNotes(notes);
		} else {
			System.out.println("\nERROR: Wrong context found for setting notes!!!\n");
		}
	}
	
	/*
	 * These methods are used to simplify event handling.
	 * Every SBML type JComboBox has to know to which SBmodel context it belongs.
	 * (Functions, States, Parameters, Variables, Reactions xor Events) 
	 */
	public void setSBmodelContext(SBmodelContextType sbmContext) {
		this.sbmContext = sbmContext;
	}
	
	public void setSBmodelContext(String sbmContext) {
		SBmodelContextType.valueOf(sbmContext);
	}
	
	public SBmodelContextType getSBmodelContext() {
		return sbmContext;
	}
	
//	public String getSBmodelContext() {
//		if (sbmContext != null) {
//			return sbmContext.toString();
//		} else {
//			// This case normaly should not be reachable!!!
//			return "NOT SPECIFIED";
//		}
//	}

}
