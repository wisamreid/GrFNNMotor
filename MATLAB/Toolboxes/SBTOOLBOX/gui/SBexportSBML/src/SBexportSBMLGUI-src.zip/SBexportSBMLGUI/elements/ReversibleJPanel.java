package SBexportSBMLGUI.elements;

/**************************************************************************
 * ReversibleJPanel: creates a JPanel containing a JCheckBox containing
 *                   the state of the reversible field of reactions in
 *                   the SBmodelJava.
 *                   To observe state changes register a
 *                   ReversibleItemListener!
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JCheckBox;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.listener.*;

public class ReversibleJPanel extends SBmodelGenericJPanel {
	
	public ReversibleJPanel(int sbmIndex, double state) {
		
		JCheckBox reversibleJChB = new JCheckBox("reversible", false);
		reversibleJChB.setName(String.valueOf(sbmIndex));
		
		/*
		 * Test wether there is an input value for the reaction reversible field.
		 * If yes, apply the state of the JCheckBox!
		 */
		if (state==1) reversibleJChB.setSelected(true);
		
		/*
		 * Instantiate ItemListener for JCheckBox and add both to the JPanel.
		 */
		ReversibleItemListener reversibleIL = new ReversibleItemListener();
		reversibleJChB.addItemListener(reversibleIL);
		add(reversibleJChB);
	}
}
