package SBexportSBMLGUI.listener;

/**************************************************************************
 * SBMLTypeItemListener: reacts on changes of the SBML type JComboBox and
 *                       stores the result in the SBmodelJava.
 *                       If the SBML type is not "Specie" the unit type
 *                       JComboBox has to be cleared and deactivated.
 *                       
 *                       If the SBML type is changed to or from "Compartment"
 *                       to another value the compartment JComboBox has to
 *                       be updated.
 *                       
 *                       The case wether the SBML type JComboBox is about
 *                       a state, a parameter or a variable is solved
 *                       through late binding and the abstract
 *                       SBmodelGenericJPanel.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JComboBox;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.elements.*;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class SBMLTypeItemListener implements ItemListener {
	
	JComboBox sourceJCB;
	SBMLTypeJPanel sourceJP;
	SBmodelGenericJPanel parentJP;
	
	UnitTypeJPanel unitTypePanel;
	CompartmentJPanel compartmentPanel;
	
	public SBMLTypeItemListener(UnitTypeJPanel utJP, CompartmentJPanel compJP) {
		this.unitTypePanel = utJP;
		this.compartmentPanel = compJP;
	}
		
	public void itemStateChanged(ItemEvent e) {
		/*
		 * Get the parent of the SBML type JComboBox to get the context
		 * where the information has to be stored (state, parameter, variable).
		 */
		try {
			sourceJCB = (JComboBox)e.getSource();
			sourceJP = (SBMLTypeJPanel) sourceJCB.getParent();
			parentJP = (SBmodelGenericJPanel) sourceJP.getParent();
		} catch (Exception CCE) {
			CCE.printStackTrace();
		}
		String selected = sourceJCB.getSelectedItem().toString();
		int destination = Integer.parseInt(sourceJCB.getName());
		// print out selected SBML type
		if (e.getStateChange()==ItemEvent.SELECTED) {
//			parentJP.printCurrentItem(destination);
//			System.out.println("SBML type => "+ selected);
		}
		// test what has been selected and store information to the SBmodelJava
		switch(sourceJCB.getSelectedIndex()) {
		/*
		 * SBML type "Specie" selected:
		 * 1. If SBML type was "Compartment" remove component from compartment list!
		 * 2. Instantiate a new ItemListener for the unit type JComboBox and add the
		 *    items "Amount" and "Concentration".
		 * 3. Add listener to unit type JComboBox
		 */
		case 0 :	parentJP.setSBMLType(destination, "isSpecie");
					if (e.getItem().toString().equals("SBML Compartment") && (e.getStateChange()==ItemEvent.DESELECTED)) {
						parentJP.removeItemFromCompartmentJCBs(parentJP.getName(destination));
						parentJP.makeCompartmentList(); 
					}
					unitTypePanel.getUnitTypeJCB().removeAllItems();
					unitTypePanel.getUnitTypeJCB().addItem("Amount");
					unitTypePanel.getUnitTypeJCB().addItem("Concentration");
					unitTypePanel.getUnitTypeJCB().setEnabled(true);
					compartmentPanel.getCompartmentJCB().removeAllItems();
//					compartmentPanel.getCompartmentJCB().addItem("");
					for (String compartment : parentJP.getCompartmentList()) {
						compartmentPanel.getCompartmentJCB().addItem(compartment);
					}
					compartmentPanel.getCompartmentJCB().setEnabled(true);
					break;
		/*
		 * SBML type "Parameter" selected:
		 * 1. If SBML type was "Compartment" remove component from compartment list!
		 * 2. Instantiate a new ItemListener for the unit type JComboBox, remove
		 *    all items as well as disable the unit type JComboBox.
		 * 3. Add listener to unit type JComboBox
		 */
		case 1 :	parentJP.setSBMLType(destination, "isParameter");
					if (e.getItem().toString().equals("SBML Compartment") && (e.getStateChange()==ItemEvent.DESELECTED)) {
						parentJP.removeItemFromCompartmentJCBs(parentJP.getName(destination));
						parentJP.makeCompartmentList();
					}
					unitTypePanel.getUnitTypeJCB().removeAllItems();
					unitTypePanel.getUnitTypeJCB().setEnabled(false);
					compartmentPanel.getCompartmentJCB().removeAllItems();
					compartmentPanel.getCompartmentJCB().addItem("");
					compartmentPanel.getCompartmentJCB().setEnabled(false);
					break;
		/*
		 * SBML type "Compartment" selected:
		 * 1. Add component to compartment list!
		 * 2. If this is the only compartment add all states, parameters and variables to this one.
		 * 3. Instantiate a new ItemListener for the unit type JComboBox, remove
		 *    all items as well as disable the unit type JComboBox.
		 * 4. Add listener to unit type JComboBox
		 */
		case 2 :	parentJP.setSBMLType(destination, "isCompartment");
					if (e.getStateChange()==ItemEvent.SELECTED) {
						parentJP.addItemToCompartmentJCBs(parentJP.getName(destination));
						if (parentJP.makeCompartmentList()==1) parentJP.selectItemAtCompartmentJCBs();
					}
					unitTypePanel.getUnitTypeJCB().removeAllItems();
					unitTypePanel.getUnitTypeJCB().setEnabled(false);
					compartmentPanel.getCompartmentJCB().removeAllItems();
					compartmentPanel.getCompartmentJCB().addItem("");
					for (String compartment : parentJP.getCompartmentList()) {
						if (!compartment.equals(parentJP.getName(destination)))
								compartmentPanel.getCompartmentJCB().addItem(compartment);
					}
					compartmentPanel.getCompartmentJCB().setEnabled(true);
					break;
		}
	}
		
}
