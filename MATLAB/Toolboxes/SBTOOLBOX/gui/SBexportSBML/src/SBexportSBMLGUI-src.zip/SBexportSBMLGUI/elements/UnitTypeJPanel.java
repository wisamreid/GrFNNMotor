package SBexportSBMLGUI.elements;

/**************************************************************************
 * UnitTypeJPanel: creates a JPanel containing a JComboBox containing
 *                 the items "Amount" and "Concentration" which can be
 *                 choosen if the SBML type of the corresponding component
 *                 is "Specie".
 *                 To observe state changes register a UnitTypeItemListener!
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JComboBox;

import auxiliary.javamodel.enums.*;
import SBexportSBMLGUI.*;
import SBexportSBMLGUI.listener.*;

public class UnitTypeJPanel extends SBmodelGenericJPanel {
	
	private JComboBox unitType;
	private UnitTypeItemListener unitTypeIL;
	
	public UnitTypeJPanel(int sbmIndex, SbmlSpecieUnitType preselect, SbmlType sbmlType) {
		/*
		 * Dependent on the SBML type there are two kinds of unit type
		 * JComboBoxes to add.
		 * SBML type -> "isSpecie" complete functionality
		 * SBML type -> anything else empty disabled JComboBox
		 * 
		 * Instantiation of the JComboBox and set an index
		 * (No. of state, paramter, ...) as name.
		 */
		unitType = new JComboBox();
		unitType.setName(String.valueOf(sbmIndex));
		
		if (sbmlType.equals(SbmlType.SPECIE)|| sbmlType.equals(SbmlType.NONE)) {
			
			/*
			 * For the SBML type "Specie" the user can chosse between "amount" and
			 * "concentration".
			 */
			unitType.removeAll();
			unitType.addItem("Amount");
			unitType.addItem("Concentration");
			
			/*
			 * If the state is of type "isSpecie", test wether there is an input value
			 * for the specie unit type.
			 * If yes, apply it to the JComboBox!
			 * If no, apply "amount" by default and print warning!
			 * (only for security reasons; default values should be assigned through MATLAB)
			 */
			switch(preselect) {
			case AMOUNT : unitType.setSelectedIndex(0); break;
			case CONCENTRATION : unitType.setSelectedIndex(1); break;
			case NONE : break; //System.out.println("WARNING: Unit type not predefined!!!"); break;             
			}
		} else {
			/*
			 * If SBML type is NOT "isSpecie" the JComboBox can be left
			 * empty and has to be disabled.
			 */
			unitType.setEnabled(false);
		}
		/*
		 * Of course we need a listener that reacts to changes and then we
		 * add JComboBox to JPanel.
		 */
		unitTypeIL = new UnitTypeItemListener();
		unitType.addItemListener(unitTypeIL);
		add(unitType);
		
	}
	
	/*
	 * Because the state of the unit type JComboBox changes accordingly to the state of
	 * the SBML type JComboBox we need access to the instance of the unit type Item Listener.
	 */
	public UnitTypeItemListener getUnitTypeIL() {
		return unitTypeIL;
	}
	
	public JComboBox getUnitTypeJCB() {
		return unitType;
	}

}
