package SBexportSBMLGUI.listener;

/**************************************************************************
 * ReversibleUnitTypeItemListener: reacts on changes of the reversible
 *                                 JCheckBox and stores the result in the
 *                                 SBmodelJava.
 *                                 The case wether the reversible JCheckBox
 *                                 is about a state, a parameter or a
 *                                 variable is solved through late binding
 *                                 and the abstract SBmodelGenericJPanel.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.elements.*;

public class ReversibleItemListener implements ItemListener {
	
	JCheckBox sourceJChB;
	ReversibleJPanel sourceJP;
	SBmodelGenericJPanel parentJP;
	
	public void itemStateChanged(ItemEvent e) {
		// get the parent of the reversible JCheckBox to get the context
		// where the information has to be stored (state, parameter, variable).
		try {
			sourceJChB = (JCheckBox)e.getSource();
			sourceJP = (ReversibleJPanel) sourceJChB.getParent();
			parentJP = (SBmodelGenericJPanel) sourceJP.getParent();
		} catch (Exception CCE) {
			CCE.printStackTrace();
		}
		int destination = Integer.parseInt(sourceJChB.getName());
//		parentJP.printCurrentItem(destination);
		// test wether JCheckBox is selected or deselected and
		// store information in SBmodelJava
		int change = e.getStateChange();
		if (change == ItemEvent.SELECTED) {
			parentJP.setReversible(destination, 1);
//			System.out.println("reversible => activated");
		} else if (change == ItemEvent.DESELECTED) {
			parentJP.setReversible(destination, 0);
//			System.out.println("reversible => deactivated");
		}
	}

}
