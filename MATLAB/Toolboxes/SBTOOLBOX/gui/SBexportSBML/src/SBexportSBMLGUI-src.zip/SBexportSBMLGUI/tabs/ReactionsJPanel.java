package SBexportSBMLGUI.tabs;

/**************************************************************************
 * ReactionsJPanel: creates a JPanel containing all adjustable elements
 *                  that are needed to help to convert the SBmodel
 *                  Reactions to fit into a SBML file.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class ReactionsJPanel extends SBmodelGenericJPanel {
	
	GridBagLayout gbl;
	GridBagConstraints gbc;
	
	public ReactionsJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.REACTION);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no reactions print Message!
		 */
		if (sbmj.getNumberOfReactions()==0) {
			setLayout(new FlowLayout());
			JLabel noReactions = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no reactions.");
			noReactions.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noReactions);
		} else {
			/*
			 * SBmodel contains reactions!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel reactions!
			 */
			gbl = new GridBagLayout();
			setLayout(gbl);
			
//			 leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel reactionName = new ColumnHeadJPanel("Reaction Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(reactionName, gbc);
			add(reactionName);
			
			ColumnHeadJPanel formula = new ColumnHeadJPanel("Formula");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(formula, gbc);
			add(formula);
			
			ColumnHeadJPanel reversible = new ColumnHeadJPanel("Reversible");
			gbc = setGBC(4, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(reversible, gbc);
			add(reversible);
			
			ColumnHeadJPanel reactionNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(5, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(reactionNotes, gbc);
			add(reactionNotes);
		}
		
		/* 
		 * Place all items for each SBmodel reaction in one row (repeat for all reactions).
		 * 1. JLabel Reaction Name  
		 * 2. JButton Formula calls JDialog with editable JTextArea for formulas
		 * 3. JCheckBox Reversible determines wether the reaction is reversible
		 * 4. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int reactionscount=sbmj.getNumberOfReactions();
		for (int i=0; i<reactionscount; i++) {
			int reactionIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(reactionIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getReaction(reactionIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
			
			GenericJButtonJPanel formulaJB = new GenericJButtonJPanel(reactionIndex, TriggerSource.FORMULA);  
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(formulaJB, gbc);
			add(formulaJB);
						
			ReversibleJPanel reversibleJP = new ReversibleJPanel(reactionIndex, sbmj.getReaction(reactionIndex).getReversible());
			gbc = setGBC(4, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(reversibleJP, gbc);
			add(reversibleJP);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(reactionIndex, TriggerSource.NOTES);  
			gbc = setGBC(5, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
	
}
