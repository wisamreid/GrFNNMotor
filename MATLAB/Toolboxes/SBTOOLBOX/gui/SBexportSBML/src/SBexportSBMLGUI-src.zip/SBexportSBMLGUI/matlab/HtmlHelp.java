package SBexportSBMLGUI.matlab;

import com.mathworks.jmi.Matlab;

public class HtmlHelp implements Runnable {
	
	private static Matlab currentSession;
	
	/**
	 * This class causes the MATLAB browser to open
	 * the "SBexportSBML_HELP.html" file which should
	 * contain additional help Information! 
	 */
	
	/*
	 * It's assumed that the MATLAB Webbrowser is also
	 * implemented in Java, if we run in the normal
	 * way there would occur deadlock in the MATLAB
	 * environment.
	 * There for we need to call it in an additional
	 * thread. 
	 */
	
	public void run() {
		currentSession = new Matlab();
		// call Matlab build in browser with html help file
		try {
			currentSession.eval("web('SBexportSBML_HELP.html')");
		} catch ( Exception ex) {
			ex.printStackTrace();
		}	
	}
	

}