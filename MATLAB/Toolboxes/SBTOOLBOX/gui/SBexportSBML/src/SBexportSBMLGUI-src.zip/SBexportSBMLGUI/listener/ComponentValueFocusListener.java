package SBexportSBMLGUI.listener;

/**************************************************************************
 * ComponentValueFocusListener: reacts on changes of the value or initial
 *                              condition JTextField and stores the result
 *                              in the SBmodelJava.
 *                              The information is stored when the JTextField
 *                              lose it the focus (e.g. another button is 
 *                              pressed or sth. like that).
 *                              Before the data will be written a test is
 *                              performed wether it can be converted into a
 *                              double without error.
 *                              The case wether the JTextField is about
 *                              a state initial condition or a variable value
 *                              is solved through late binding and the abstract
 *                              SBmodelGenericJPanel.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JTextField;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.elements.*;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class ComponentValueFocusListener implements FocusListener {
	
	JTextField sourceJTF;
	ComponentValueJPanel sourceJP;
	SBmodelGenericJPanel parentJP;
	
	public void focusLost(FocusEvent e) {
		// get the parent of the JTextField to get the context
		// where the information has to be stored (state, parameter).
		try {
			sourceJTF = (JTextField)e.getSource();
			sourceJP = (ComponentValueJPanel) sourceJTF.getParent();
			parentJP = (SBmodelGenericJPanel) sourceJP.getParent();
		} catch (Exception CCE) {
			CCE.printStackTrace();
		}
		int destination = Integer.parseInt(sourceJTF.getName());
//		parentJP.printCurrentItem(destination);
		
		/*
		 * Test wether data of JTextField is double.
		 * If yes, store information to SBmodelJava.
		 * If no, print error message to console and restore old value in the JTextField! 
		 */
		try {
			double value = Double.parseDouble(sourceJTF.getText());
			parentJP.setValue(destination, value);
//			System.out.println("Initial Condition -> "+String.valueOf(value));
		} catch (Exception ex) {
			sourceJTF.setText(String.valueOf(parentJP.getValue(destination)));
//			System.out.println("Initial Condition has to be Double! \t Reset to: "+String.valueOf(parentJP.getValue(destination)));
		}
	}
	
	public void focusGained(FocusEvent e) {
		
	}

}
