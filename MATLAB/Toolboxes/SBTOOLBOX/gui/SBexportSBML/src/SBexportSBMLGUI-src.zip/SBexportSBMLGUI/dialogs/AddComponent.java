package SBexportSBMLGUI.dialogs;
/**************************************************************************
 * HelpJTextAreaJDialog: Opens a JDialog frame and prints a help text
 *                       dependend on the choosen Menu ITem from 
 *                       GUIJMenuBar-
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import auxiliary.javamodel.SBmodelJava;
import auxiliary.javamodel.SBmodelTools;
import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.InfoMessage;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AddComponent extends JDialog implements ActionListener, KeyListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 11);
	private JButton okButton, cancelButton;
	private JTextField addTextField;
	
	private static final int dialogWidth = 300;
	private static final int dialogHeight = 150;
	
	private static final String startStr = "<HTML>Please type the name of the ";
	private static final String endStr = "you want to add to the SBmodel!</HTML>";
	
	private SB2SBMLGUI owner;
	private SBmodelJava sbmj;
	private SBmodelContextType contextType;
	
	public AddComponent(SB2SBMLGUI owner, SBmodelContextType contextType, SBmodelJava sbmj) {
		
		super(owner, null, false);
		
		setTitle("Add "+contextType.toString()+" Dialog");
		this.owner = owner;
		this.sbmj = sbmj;
		this.contextType = contextType; 
		
		
		
		setSize(dialogWidth, dialogHeight);
		setLocation(300,300);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		addTextField = new JTextField(15);
		addTextField.setText("New"+contextType.toString());
		addTextField.addKeyListener(this);
		double textFieldWidth = ((Dimension)addTextField.getPreferredSize()).getWidth();
		
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(null);
		centerPanel.setBounds(0, 10, 280, 100);
		
		JLabel infoLabel = new JLabel(startStr+contextType.toString().toLowerCase()+"<br>"+endStr);
		infoLabel.setFont(font);
		double infoLabelWidth = ((Dimension)infoLabel.getPreferredSize()).getWidth();
		infoLabel.setBounds((int)((dialogWidth-infoLabelWidth)/2), 0, (int)infoLabelWidth, 40);
		JLabel textFieldLabel = new JLabel(contextType.toString()+" Name: ");
		textFieldLabel.setFont(font);
		double textFieldLabelWidth = ((Dimension)textFieldLabel.getPreferredSize()).getWidth();
		
		int beginTextFieldLabel = (int)((dialogWidth-(textFieldLabelWidth+textFieldWidth+5))/2);
		int beginTextField = beginTextFieldLabel + (int)textFieldLabelWidth + 5;
		centerPanel.add(infoLabel);
		textFieldLabel.setBounds(beginTextFieldLabel, 40, (int)textFieldLabelWidth, 30);
		centerPanel.add(textFieldLabel);
		addTextField.setBounds(beginTextField, 40, (int)textFieldWidth, 30);
		centerPanel.add(addTextField);
		
		cp.add("Center", centerPanel);
		
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		okButton = new JButton("Ok");
		okButton.addActionListener(this);
		buttonPanel.add(okButton);
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		buttonPanel.add(cancelButton);
		
		cp.add("South", buttonPanel);
		
	}
	
	public void actionPerformed(ActionEvent event) {
		JButton source = (JButton)event.getSource();
		if (source == okButton) {
			if (SBmodelTools.existsName(sbmj, addTextField.getText())) {
				JDialog warning = new Warning(this, InfoMessage.NAME_COLLISION);
				warning.setVisible(true);
			} else if (!SBmodelTools.isValidName(addTextField.getText())) {
				JDialog warning = new Warning(this, InfoMessage.BAD_NAME);
				warning.setVisible(true);
			} else {
				switch(contextType) {
				case STATE : sbmj.addState(addTextField.getText()); break;
				case PARAMETER : sbmj.addParameter(addTextField.getText()); break;
				case VARIABLE : sbmj.addVariable(addTextField.getText()); break;
				case REACTION : sbmj.addReaction(addTextField.getText()); break;
				case EVENT : sbmj.addEvent(addTextField.getText()); break;
				case FUNCTION : sbmj.addFunction(addTextField.getText()); break;
				}
				this.setVisible(false);
				this.dispose();
				owner.updateTab(contextType);
			}
		} else if (source == cancelButton) {
			this.setVisible(false);
			this.dispose();
		}
	}
	
	public void keyPressed(KeyEvent event) {
		if (event.getKeyCode()==event.VK_ENTER) {
			okButton.doClick();
		}
	}
	
	public void keyReleased(KeyEvent event) { }
	
	public void keyTyped(KeyEvent event) { }
	
}
