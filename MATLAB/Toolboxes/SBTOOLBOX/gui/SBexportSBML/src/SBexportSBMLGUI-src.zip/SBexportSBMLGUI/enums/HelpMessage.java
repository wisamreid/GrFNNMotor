package SBexportSBMLGUI.enums;

public enum HelpMessage {
	
	GENERAL("General Help", "General", 
	"The editor shows a view of the complete model. " +
	"You can edit the model using the tabs, buttons,comboboxes or textfields (Notes, States, etc.). \n\n" +
	"On pressing the notes button a dialog opens where you can enter notes about the model. Any characters are allowed"),

	STATES_HELP("States Help", "States", 
	"Please type \"help SBexportSBML\" at the MATLAB console."),

	PARAMETERS_HELP("Parameters Help", "Parameters", 
	"Please type \"help SBexportSBML\" at the MATLAB console."),

	VARIABLES_HELP("Variables Help", "Variables", 
	"Please type \"help SBexportSBML\" at the MATLAB console."),

	REACTIONS_HELP("Reactions Help", "Reactions", 
	"In this tab you can edit the models reactions. " +
	"The expression can contain states, variables, and parameters. " +
	"Reaction names are not allowed to have the same name as states, parameters, variables, or functions. " +
	"The identifier \"reversible\" should be checked when a reaction is reversible only. " +
	"In the reaction comments (notes) the character \"=\" is NOT ALLOWED!\n" +
	"You can specify the ODEs for species in terms of reactions or by directly using kinetic formulas in the ODEs. " +
	"In the latter case reactions do not need to be specified. " +
	"A combination of both approaches is possible but not very consistent, and should therefore be avoided."),

	FUNCTIONS_HELP("Functions Help", "Functions", 
	"In this tab you can edit functions that are used in the mathematical expressions of the model. " +
	"Function names are not allowed to have the same name as states, parameters, variables, or reactions. " +
	"The optional comment (notes) is not allowed to contain the character \"=\"."),

	EVENTS_HELP("Events Help", "Events", 
	"In this tab you can edit events that are used to set state variables of the model to certain values when a certain condition is fulfilled. " +
	"Contrary to SBML here in this toolbox no delay is allowed between the firing of an event and its execution. " +
	"The values can be numerical but also be represented by a formula that is allowed to contain states, parameters, etc. " +
	"The trigger expression has to have the following simple syntax: \"operator(expression1,expression2)\", " +
	"where the operator can be chosen as \"ge,gt,le,lt\". The two expressions have the same syntax as the values. " +
	"The event is only fired when the trigger function goes from false to true. " +
	"The optional comment (notes) is not allowed to contain the character \"=\"."),
	
	ABOUT("About", "About", 
	"Information:\n============\n" +
	"Systems Biology Toolbox for MATLAB\n" +
	"Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se\n\n" +
	"SBML export Interface\n" +
	"Copyright (C) 2005 Gunnar Drews, student at university of Rostock Department of Computer Science, Gunnar.Drews@Uni-Rostock.de\n\n" +
	"This program is free software; you can redistribute it and/or" +
	"modify it under the terms of the GNU General Public License" +
	"as published by the Free Software Foundation; either version 2" +
	"of the License, or (at your option) any later version.\n\n"+
	"This program is distributed in the hope that it will be useful," +
	"but WITHOUT ANY WARRANTY; without even the implied warranty of" +
	"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the" +
	"GNU General Public License for more details.\n\n" + 
	"You should have received a copy of the GNU General Public License" +
	"among with this program; if not, write to the Free Software"+
	"Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.");
	
	private String kind;
	private String menuItem;
	private String helpText;
	
	private HelpMessage(String kind, String menuItem, String helpText) {
		this.kind = kind;
		this.menuItem = menuItem;
		this.helpText = helpText;
	}
	
	public String getHelpText() {
		return helpText;
	}
	
	public String getHelpName() {
		return kind;
	}
	
	public String getMenuItem() {
		return menuItem;
	}
	
	public String toString() {
		return menuItem;
	}

}
