package SBexportSBMLGUI.elements;

/**************************************************************************
 * ComponentValueJPanel: creates a JPanel containing a JTextField which
 *                       is used to alter the following information
 *                       (states initial condition or parameters value).
 *                       The information stored in this JTextField will
 *                       be saved to the SBmodelJava if the specific
 *                       JTextField lose the focus.
 *                       Therefore a the ComponentValueFocusListener is
 *                       registered to the JTextField.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JTextField;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.listener.*;

public class ComponentValueJPanel extends SBmodelGenericJPanel {
	
	public ComponentValueJPanel(int sbmIndex, double value) {
		
		JTextField valueJTF = new JTextField(String.valueOf(value), 10);
		valueJTF.setHorizontalAlignment(JTextField.LEFT);
		valueJTF.setName(String.valueOf(sbmIndex));
		
		ComponentValueFocusListener cvFL = new ComponentValueFocusListener();
		valueJTF.addFocusListener(cvFL);
		add(valueJTF);
	}

}
