package SBexportSBMLGUI.listener;

/**************************************************************************
 * GenericJButtonActionListener: a listener which is assigned to all buttons
 *                               found in the tabs of the SB export SBML GUI.
 *                               
 *                               If one of these buttons is pressed a JDialog
 *                               which contains a JTextArea or in the case
 *                               of events assignment a JTable is opened.
 *                               
 *                               The Membership is again solved through late
 *                               binding and the abstract SBmodelGenericJPanel.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JButton;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.dialogs.EventsAssignmentTable;
import SBexportSBMLGUI.dialogs.GenericTextArea;
import SBexportSBMLGUI.elements.*;
import SBexportSBMLGUI.enums.TriggerSource;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GenericJButtonActionListener implements ActionListener {
	
	private TriggerSource trigger;
	private int index;
	
	private JButton componentButton;
	private SBmodelGenericJPanel parent;
	private SB2SBMLGUI f;
	
	public GenericJButtonActionListener(int index, TriggerSource trigger) {
		this.index = index;
		this.trigger = trigger;
	}
	
	public void actionPerformed(ActionEvent e) {
		componentButton = (JButton)e.getSource(); 
		// For a JDialog we have to pass the frame which calls the dialog.
		f = (SB2SBMLGUI) componentButton.getTopLevelAncestor();
		/*
		 * To have access to the right instances of our SBmodel we need the
		 * JPanel.
		 * The first parent would be the JPanel which contains the JButton and
		 * the second is the one with all information ie. SBmodel.states...
		 */
		parent = (SBmodelGenericJPanel) componentButton.getParent().getParent();
		if (trigger.equals(TriggerSource.ASSIGNMENT)) {
			EventsAssignmentTable eaJTJD = new EventsAssignmentTable(f, parent, trigger, index);
			eaJTJD.setVisible(true);
		} else {
			GenericTextArea genericJTAJD = new GenericTextArea(f, parent, trigger, index);
			genericJTAJD.setVisible(true);
		}
	}

}
