package SBexportSBMLGUI.tabs;
/**************************************************************************
 * EventsJPanel: creates a JPanel containing all adjustable elements
 *               that are needed to help to convert the SBmodel
 *               Events to fit into a SBML file.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class EventsJPanel extends SBmodelGenericJPanel {
	
	GridBagLayout gbl;
	GridBagConstraints gbc;
	
	public EventsJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.EVENT);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no events print Message!
		 */
		if (sbmj.getNumberOfEvents()==0) {
			setLayout(new FlowLayout());
			JLabel noEvents = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no events.");
			noEvents.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noEvents);
		} else {
			/*
			 * SBmodel contains events!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel events!
			 */
			gbl = new GridBagLayout();
			setLayout(gbl);
			
//			 leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel eventName = new ColumnHeadJPanel("Event Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(eventName, gbc);
			add(eventName);
			
			ColumnHeadJPanel trigger = new ColumnHeadJPanel("Trigger");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(trigger, gbc);
			add(trigger);
			
			ColumnHeadJPanel assignment = new ColumnHeadJPanel("Assignment");
			gbc = setGBC(4, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(assignment, gbc);
			add(assignment);
			
			ColumnHeadJPanel eventNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(5, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(eventNotes, gbc);
			add(eventNotes);
		}
		
		/* 
		 * Place all items for each SBmodel event in one row (repeat for all events).
		 * 1. JLabel Event Name
		 * 2. JButton Trigger calls JDialog with editable JTextArea for trigger  
		 * 3. JButton Assignment calls JDialog with editable JTable for assignment
		 * 4. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int eventscount=sbmj.getNumberOfEvents();
		for (int i=0; i<eventscount; i++) {
			int eventIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(eventIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getEvent(eventIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
			
			GenericJButtonJPanel triggerJB = new GenericJButtonJPanel(eventIndex, TriggerSource.TRIGGER);  
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(triggerJB, gbc);
			add(triggerJB);
			
			GenericJButtonJPanel assignmentJB = new GenericJButtonJPanel(eventIndex, TriggerSource.ASSIGNMENT);  
			gbc = setGBC(4, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(assignmentJB, gbc);
			add(assignmentJB);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(eventIndex, TriggerSource.NOTES);  
			gbc = setGBC(5, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
	
}
