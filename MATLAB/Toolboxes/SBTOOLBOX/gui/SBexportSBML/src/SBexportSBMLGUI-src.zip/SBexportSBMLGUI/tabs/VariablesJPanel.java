package SBexportSBMLGUI.tabs;

/**************************************************************************
 * VariablesJPanel: creates a JPanel containing all adjustable elements
 *                  that are needed to help to convert the SBmodel
 *                  Variables to fit into a SBML file.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class VariablesJPanel extends SBmodelGenericJPanel {
	
	private GridBagLayout gbl;
	private GridBagConstraints gbc;
	
	public VariablesJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.VARIABLE);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no variables print Message!
		 */
		if (sbmj.getNumberOfVariables()==0) {
			setLayout(new FlowLayout());
			JLabel noVars = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no variables.");
			noVars.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noVars);
		} else {
			/*
			 * SBmodel contains variables!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel variables!
			 */
			gbl = new GridBagLayout();
			setLayout(gbl);
			
//			 leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel variableName = new ColumnHeadJPanel("Variable Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(variableName, gbc);
			add(variableName);
			
			ColumnHeadJPanel value = new ColumnHeadJPanel("Formula");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(value, gbc);
			add(value);
			
			ColumnHeadJPanel variableType = new ColumnHeadJPanel("SBML Type");
			gbc = setGBC(4, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(variableType, gbc);
			add(variableType);
			
			ColumnHeadJPanel specieUnitType = new ColumnHeadJPanel("Unit Type");
			gbc = setGBC(7, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(specieUnitType, gbc);
			add(specieUnitType);
			
			ColumnHeadJPanel variableCompartment = new ColumnHeadJPanel("Compartment");
			gbc = setGBC(10, 0, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(variableCompartment, gbc);
			add(variableCompartment);
			
			ColumnHeadJPanel variableNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(13, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(variableNotes, gbc);
			add(variableNotes);
		}
		
		/* 
		 * Place all items for each SBmodel variable in one row (repeat for all variables).
		 * 1. JLabel Variable Name
		 * 2. JButton Formula calls JDialog with editable JTextArea for Formula
		 * 3. JComboBox SBML Type (choose specie, parameter, variable or compartment)
		 * 4. JComboBox Unit Type (if SBML Type -> specie : choose amount or concentration
		 * 5. JComboBox Compartment (choose to which compartment the state belongs)
		 * 6. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int variablescount=sbmj.getNumberOfVariables();
		for (int i=0; i<variablescount; i++) {
			int variableIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(variableIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getVariable(variableIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
						
			GenericJButtonJPanel formulaCBJP = new GenericJButtonJPanel(variableIndex, TriggerSource.FORMULA);  
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(formulaCBJP, gbc);
			add(formulaCBJP);
			
			/*
			 * Create the JComboBoxes for the choice of the unit type first and then for
			 * the SBML type, afterards add them to the JPanel.
			 * This is necessary because the functionality of the unit type JComboBox changes
			 * accordingly to the selected item of the SBML type JComboBox.
			 * So we have to provide the instances of unit type JPanel and unit type ItemListener
			 * to SBML type JPanel!
			 */
			
			UnitTypeJPanel unitTypeJP = new UnitTypeJPanel(variableIndex, sbmj.getVariable(variableIndex).getUnitType(), sbmj.getVariable(variableIndex).getType());
			gbc = setGBC(7, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(unitTypeJP, gbc);
			add(unitTypeJP);
			
			CompartmentJPanel compartmentJP = new CompartmentJPanel(variableIndex, sbmj.getVariable(variableIndex).getName(), sbmj.getVariable(variableIndex).getCompartment(), sbmj.getVariable(variableIndex).getType(), sbmj.getCompartments());
			gbc = setGBC(10, gridy, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(compartmentJP, gbc);
			add(compartmentJP);
			
			SBMLTypeJPanel sbmlTypeJP = new SBMLTypeJPanel(variableIndex, sbmj.getVariable(variableIndex).getType(), unitTypeJP, compartmentJP);
			gbc = setGBC(4, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(sbmlTypeJP, gbc);
			add(sbmlTypeJP);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(variableIndex, TriggerSource.NOTES);  
			gbc = setGBC(13, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
	
}
