package SBexportSBMLGUI;

/**************************************************************************
 * SBexportSBMLGUI: creates a Frame containing tabs for all adjustable
 *                  elements which are needed to export a propper SBML file.
 *                  It serves as starting point where all specific JPanels
 *                  are called from.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import SBexportSBMLGUI.dialogs.AddComponent;
import SBexportSBMLGUI.dialogs.GenericTextArea;
import SBexportSBMLGUI.dialogs.Question;
import SBexportSBMLGUI.dialogs.RemoveComponent;
import SBexportSBMLGUI.dialogs.RenameComponent;
import SBexportSBMLGUI.dialogs.Warning;
import SBexportSBMLGUI.enums.DecisionMessage;
import SBexportSBMLGUI.enums.InfoMessage;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.matlab.HtmlHelp;
import SBexportSBMLGUI.matlab.JavaModel;
import SBexportSBMLGUI.matlab.SBML;
import SBexportSBMLGUI.menu.GUIJMenuBar;
import SBexportSBMLGUI.tabs.EventsJPanel;
import SBexportSBMLGUI.tabs.FunctionsJPanel;
import SBexportSBMLGUI.tabs.ParametersJPanel;
import SBexportSBMLGUI.tabs.ReactionsJPanel;
import SBexportSBMLGUI.tabs.StatesJPanel;
import SBexportSBMLGUI.tabs.VariablesJPanel;
import auxiliary.javamodel.SBmodelJava;
import auxiliary.javamodel.SBmodelTools;

public class SB2SBMLGUI extends JFrame implements ActionListener {
	
	private JButton addButton, removeButton, renameButton, helpButton;
	private JPanel states, parameters, variables, reactions, events, functions;
	private JTabbedPane sbModelContentTP;
	
	SBmodelJava sbmj;
	ChangesAppliedObject changesFlag;
	
	public SB2SBMLGUI(SBmodelJava model) {
		this(model, new ChangesAppliedObject());
	}
	
	public SB2SBMLGUI(SBmodelJava model, ChangesAppliedObject appChanges) {
		// create a JFrame with title...
		super("SB export SBML GUI");
		// copy the reference to the SBmodelJava to a local variable
		sbmj=model;
		sbmj.backupSBMJ();
		changesFlag = appChanges;
		
		/*
		 * Count all predefined compartments in the SBmodelJava.
		 * In the abstract class SBmodelGenericJPanel an array is build up
		 * where all compartments JComboBoxes are stored in.
		 * This grants a very easy access to the compartment JCBs when an item
		 * has to be added or removed. 
		 */
		sbmj.makeCompartmentList();
		SBmodelGenericJPanel help = new SBmodelGenericJPanel();
		int compartmentJCBsCount = sbmj.getNumberOfStates()+sbmj.getNumberOfParameters()+sbmj.getNumberOfVariables();
		help.setNumberOfComparmentJCBs(compartmentJCBsCount);
		
		
		setSize(950, 600);
		// new in J2SE Version 5 (doesn't work under MATLAB)
		//setLocationByPlatform(true);
		setLocation(100,50);
		
		// set up a new JMenuBar (with help menu) and add it to the JFrame
		GUIJMenuBar helpMenu = new GUIJMenuBar();
		setJMenuBar(helpMenu);
		
		// all content shown in the JFrame has to be painted on the 
		// content pane and not directly to the frame like in AWT
		Container cp = getContentPane();
		
		JPanel jpanel = new JPanel();
		jpanel.setLayout(new BorderLayout());
		JPanel upperJPanel = new JPanel();
		
		// create the upper JPanel of the GUI containing the SBmodel name and
		// a button which assures access to the SBmodel notes (assignment -> left)
		upperJPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		upperJPanel.setBorder(BorderFactory.createEtchedBorder());		
		String sbmNameStr = "";
		// test wether SBmodel name is empty or not and create specific JLabel with title
		if (sbmj.getName()=="") sbmNameStr+="SBML export of SBmodel: \"untitled\"";
		else sbmNameStr+="SBML export of SBmodel: "+sbmj.getName();
		JLabel sbmNameJL = new JLabel(sbmNameStr);
		sbmNameJL.setFont(new Font("SansSerif", Font.PLAIN, 24));
		// add button for SBmodel notes and register local ActionListener to it
		JButton sbmNotesJB = new JButton("SBmodel Notes");
		sbmNotesJB.addActionListener(this);
		// add JLabel and JButton + place both in the upper space of the content pane
		upperJPanel.add(sbmNameJL);
		upperJPanel.add(sbmNotesJB);
		jpanel.add("North", upperJPanel);
		
		// add all SBmodel categories to a JTabbedPane and place them in
		// the center JPanel of the gui
		sbModelContentTP = new JTabbedPane();
		setTabs();
		sbModelContentTP.addTab("States", new JScrollPane(states));
		sbModelContentTP.addTab("Parameters", new JScrollPane(parameters));
		sbModelContentTP.addTab("Variables", new JScrollPane(variables));
		sbModelContentTP.addTab("Reactions", new JScrollPane(reactions));
		sbModelContentTP.addTab("Events", new JScrollPane(events));
		sbModelContentTP.addTab("Functions", new JScrollPane(functions));
		
		
		JPanel sbModelContentPanel = new JPanel();
		sbModelContentPanel.setLayout(new BorderLayout());
		sbModelContentPanel.setBorder(BorderFactory.createEtchedBorder());
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		addButton = new JButton("Add");
		addButton.addActionListener(new SBmodelActionAdapter(this));
		buttonPanel.add(addButton);
		removeButton = new JButton("Remove");
		removeButton.addActionListener(new SBmodelActionAdapter(this));
		buttonPanel.add(removeButton);
		renameButton = new JButton("Rename");
		renameButton.addActionListener(new SBmodelActionAdapter(this));
		buttonPanel.add(renameButton);
		helpButton = new JButton("Help");
		helpButton.addActionListener(new SBmodelActionAdapter(this));
		buttonPanel.add(helpButton);
		sbModelContentPanel.add("Center", sbModelContentTP);
		sbModelContentPanel.add("South", buttonPanel);
		
		jpanel.add("Center", sbModelContentPanel);
		
		// in the lower JPanel we add two buttons to the gui and register
		// local ActionListener to them (on "Exit" button and one button
		// which has to call the converting MATLAB m-file later
		JPanel lowerJPanel = new JPanel();
		lowerJPanel.setBorder(BorderFactory.createEtchedBorder());
		JButton cancel = new JButton("Cancel");
		cancel.setToolTipText("exit gui without applying changes to SBmodel");
		cancel.addActionListener(this);
		JButton exit = new JButton("Exit");
		exit.setToolTipText("apply changes to SBmodel and exit gui");
		exit.addActionListener(this);
		JButton export = new JButton("Export SBML");
		export.setToolTipText("apply changes to SBmodel and export it to SBML");
		export.addActionListener(this);
		lowerJPanel.add(cancel);
		lowerJPanel.add(exit);
		lowerJPanel.add(export);
		jpanel.add("South", lowerJPanel);
		
		// add the JPanel which holds all the other stuff to the content pane
		cp.add(jpanel);
		
		// make JFrame visible
		setVisible(true);
		// standard routine to apply the closing function to the title bar (X button)
		// but this also closes MATLAB !?!
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// this one works ;-)
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// therefor these old method of the former AWT Frame is used
		//addWindowListener(new WindowClosingAdapter(true));
	}
	
	/*
	 * react when a button from the main window / frame is pressed
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if (cmd.equals("SBmodel Notes")) {
			GenericTextArea genericJTAJD = new GenericTextArea(this, TriggerSource.SBM_NOTES);
			genericJTAJD.setVisible(true);
		}
		if (cmd.equals("Cancel")) {
			//changesFlag.setEnabled(false); 
			sbmj.restoreSBMJ();
			this.setVisible(false);
			this.dispose();
		}
		if (cmd.equals("Exit")) {
			//changesFlag.setEnabled(true);
			/*
			 * Another option to return a changed SBmodelJava into the
			 * Matlab Development Environment, but not used.
			 */
			JavaModel.applyChanges(sbmj);
			System.out.println("Changes have been saved to your model!");
			System.out.println("You can access the changed model through the variable \"changedModel\".");
			this.setVisible(false);
			this.dispose();
		}
		// later on hopefully call the M-file which translates the SBmodel to
		// the SBML Structure used by the SBMLToolbox lib
		if (cmd.equals("Export SBML"))  {
			// test wether the model contains at least one compartment
			// (necessary for SBML format)
			String loopStr = SBmodelTools.isLoopInCompartments(sbmj);
			if (loopStr.equals("")) {
				if (sbmj.getCompartments().size()>0) {
					if (SBmodelTools.checkNumberOfRootCompartments(sbmj)==1) {
						if (SBmodelTools.allSBmodelStatesWithinCompartments(sbmj)) {
							if (SBmodelTools.allSBmodelParametersWithinCompartments(sbmj)) {
								if (SBmodelTools.allSBmodelVariablesWithinCompartments(sbmj)) {
									// the SBmodel contains compartment(s) and all
									// components are assinged to them
									// now we can call the OutputSBML()
									// function in MATLAB
									SBML.write2file(sbmj);
								} else { // not all variables are assinged to compartments
									JDialog dialog = new Warning(this, InfoMessage.NO_COMPARTMENT_SELECTED_VARIABLE);
									dialog.setVisible(true);
								} // end else not all variables are assinged to compartments
							} else { // not all parameters are assinged to compartments
								JDialog dialog = new Warning(this, InfoMessage.NO_COMPARTMENT_SELECTED_PARAMETER);
								dialog.setVisible(true);
							} // end else not all parameters are assinged to compartments
						} else { // not all states are assinged to compartments
							JDialog dialog = new Warning(this, InfoMessage.NO_COMPARTMENT_SELECTED_STATE);
							dialog.setVisible(true);
						} // end else not all states are assinged to compartments
					} else { // no or more than one root compartment found
						if (SBmodelTools.checkNumberOfRootCompartments(sbmj)==0) {
							// case no root compartment defined (normally impossible ;-))
							JDialog dialog = new Warning(this, InfoMessage.NO_ROOT_COMPARTMENT);
							dialog.setVisible(true);
						} else {
							Question dialog = new Question(this, DecisionMessage.TOO_MANY_ROOT_COMPARTMENTS, sbmj);
							dialog.setVisible(true);
						}
					} // end else no or more than one root compartment found
				} else { // SBmodel contains no compartments
					Question dialog = new Question(this, DecisionMessage.ADD_DEFAULT_COMPARTMENT, sbmj);
					dialog.setVisible(true);
				} // end else SBmodel contains no compartments
			} else { // SBmodel contains loop in compartment definition
				// case loop detected in compartments
				JDialog dialog = new Warning(this, InfoMessage.LOOP_IN_COMPARTMENTS, loopStr);
				dialog.setVisible(true);
			} // end else SBmodel contains loop in compartment definition
		}
	}
	
	// following two methods are aliases and used to access the private
	// SBmodelJava (or the other way round now access can be restricted)
	public String getSBMJNotes() {
		return sbmj.getNotes();
	}
	
	public void setSBMJNotes(String notes) {
		sbmj.setNotes(notes);
	}

	public static void main(String[] args) {
		SBmodelJava test = new SBmodelJava();
		TestSBmodel model = new TestSBmodel();
		
		SB2SBMLGUI gui = new SB2SBMLGUI(model.getSBmodel());
	}
	
	class SBmodelActionAdapter implements ActionListener {
		
		SB2SBMLGUI exportGUI;
		
		public SBmodelActionAdapter(SB2SBMLGUI exportGUI) {
			this.exportGUI = exportGUI;
		}
		
		public void actionPerformed(ActionEvent event) {
			JButton source = (JButton)event.getSource();
			int contextOrdinal = exportGUI.sbModelContentTP.getSelectedIndex();
			List<Integer> selectedIndices = null;
			switch(SBmodelContextType.toEnum(contextOrdinal)) {
			case STATE : selectedIndices = ((SBmodelGenericJPanel)states.getComponent(0)).getSelectedComponentIndices(); break;
			case PARAMETER : selectedIndices = ((SBmodelGenericJPanel)parameters.getComponent(0)).getSelectedComponentIndices(); break;
			case VARIABLE : selectedIndices = ((SBmodelGenericJPanel)variables.getComponent(0)).getSelectedComponentIndices(); break;
			case REACTION : selectedIndices = ((SBmodelGenericJPanel)reactions.getComponent(0)).getSelectedComponentIndices(); break;
			case EVENT : selectedIndices = ((SBmodelGenericJPanel)events.getComponent(0)).getSelectedComponentIndices(); break;
			case FUNCTION : selectedIndices = ((SBmodelGenericJPanel)functions.getComponent(0)).getSelectedComponentIndices(); break;
			}
			if (source == addButton) {
				AddComponent dialog = new AddComponent(exportGUI, SBmodelContextType.toEnum(contextOrdinal), sbmj);
				dialog.setVisible(true);
			} else if (source == removeButton) {
				if (selectedIndices.size()==0) {
					JDialog dialog = new Warning(exportGUI, InfoMessage.NO_SELECTION_FOR_REMOVE_COMPONENT);
					dialog.setVisible(true);
				} else {
					for (Integer index : selectedIndices) {
						RemoveComponent dialog = new RemoveComponent(exportGUI, SBmodelContextType.toEnum(contextOrdinal), sbmj, index);
						dialog.setVisible(true);
					}
				}
			} else if (source == renameButton) {
				if (selectedIndices.size()==0) {
					JDialog dialog = new Warning(exportGUI, InfoMessage.NO_SELECTION_FOR_RENAME_COMPONENT);
					dialog.setVisible(true);
				} else {
					for (Integer index : selectedIndices) {
						RenameComponent dialog = new RenameComponent(exportGUI, SBmodelContextType.toEnum(contextOrdinal), sbmj, index);
						dialog.setVisible(true);
					}
				}
			} else if (source == helpButton) {
				/*
				 * Open the html help file contained in the MATLAB
				 * environment.
				 * Because the webbrowser is probably implemented
				 * in Java too we have to start it in a new thread.
				 */
				Thread t1 = new Thread( new HtmlHelp());
				t1.start();
			}
		}
	}
	
	public void updateTab(SBmodelContextType context) {
		if (context==null) {
			// no context available, do nothing
		} else {
			switch(context) {
			case STATE : 
				states.removeAll();
				states.setLayout(new FlowLayout(FlowLayout.CENTER));
				states.add(new StatesJPanel(sbmj));
				break;
			case PARAMETER : 
				parameters.removeAll();
				parameters.setLayout(new FlowLayout(FlowLayout.CENTER));
				parameters.add(new ParametersJPanel(sbmj));
				break;
			case VARIABLE : 
				variables.removeAll();
				variables.add(new VariablesJPanel(sbmj));
				variables.setLayout(new FlowLayout(FlowLayout.CENTER));
				break;
			case REACTION : 
				reactions.removeAll();
				reactions.add(new ReactionsJPanel(sbmj));
				reactions.setLayout(new FlowLayout(FlowLayout.CENTER));
				break;
			case FUNCTION :	
				functions.removeAll();
				functions.add(new FunctionsJPanel(sbmj));
				functions.setLayout(new FlowLayout(FlowLayout.CENTER));
				break;
			case EVENT : 
				events.removeAll();
				events.add(new EventsJPanel(sbmj));
				events.setLayout(new FlowLayout(FlowLayout.CENTER));
				break;
			}
			sbModelContentTP.updateUI();
		}
	}
	
	private void setTabs() {
		// SBmodel States
		states = new JPanel();
		states.setLayout(new FlowLayout(FlowLayout.CENTER));
		states.add(new StatesJPanel(sbmj));
		// SBmodel Parameters
		parameters = new JPanel();
		parameters.setLayout(new FlowLayout(FlowLayout.CENTER));
		parameters.add(new ParametersJPanel(sbmj));
		// SBmodel Variables
		variables = new JPanel();
		variables.add(new VariablesJPanel(sbmj));
		variables.setLayout(new FlowLayout(FlowLayout.CENTER));
		// SBmodel Reactions
		reactions = new JPanel();
		reactions.add(new ReactionsJPanel(sbmj));
		reactions.setLayout(new FlowLayout(FlowLayout.CENTER));
		// SBmodel Functions
		functions = new JPanel();
		functions.add(new FunctionsJPanel(sbmj));
		functions.setLayout(new FlowLayout(FlowLayout.CENTER));
		// SBmodel Events
		events = new JPanel();
		events.add(new EventsJPanel(sbmj));
		events.setLayout(new FlowLayout(FlowLayout.CENTER));
	}
	
	public SBmodelGenericJPanel getPanel(SBmodelContextType type) {
		switch(type) {
		case STATE : return (SBmodelGenericJPanel)states.getComponent(0);
		case PARAMETER : return (SBmodelGenericJPanel)parameters.getComponent(0);
		case VARIABLE : return (SBmodelGenericJPanel)variables.getComponent(0);
		}
		return null;
	}
}
