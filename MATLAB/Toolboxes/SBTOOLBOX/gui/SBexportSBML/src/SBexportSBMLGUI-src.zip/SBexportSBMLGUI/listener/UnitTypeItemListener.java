package SBexportSBMLGUI.listener;

/**************************************************************************
 * UnitTypeItemListener: reacts on changes of the unit type JComboBox and
 *                       stores the result in the SBmodelJava.
 *                       The case wether the unit type JComboBox is about
 *                       a state, a parameter or a variable is solved
 *                       through late binding and the abstract
 *                       SBmodelGenericJPanel.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JComboBox;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.elements.*;

public class UnitTypeItemListener implements ItemListener {
	
	JComboBox sourceJCB;
	UnitTypeJPanel sourceJP;
	SBmodelGenericJPanel parentJP;
	
	/*
	 * Overwritten method which reacts on the specie unit type item listener.
	 * @see java.awt.event.ItemListener#itemStateChanged(java.awt.event.ItemEvent)
	 */
	public void itemStateChanged(ItemEvent e) {
		/*
		 * The if clause reduces work, so the data of the SBmodelJava
		 * is only changed if the ItemEvent type is "SELECTED".
		 * Get the parent of the unit type JComboBox to get the context
		 * where the information has to be stored (state, parameter, variable).
		 */
		if (e.getStateChange()==ItemEvent.SELECTED) {
			try {
				sourceJCB = (JComboBox)e.getSource();
				sourceJP = (UnitTypeJPanel)sourceJCB.getParent();
				parentJP = (SBmodelGenericJPanel)sourceJP.getParent();
			} catch (ClassCastException CCE) {
				CCE.printStackTrace();
			}
//			String selected = sourceJCB.getSelectedItem().toString();
			int destination = Integer.parseInt(sourceJCB.getName());
//			parentJP.printCurrentItem(destination);
			// test wether amount or concentration is selected and store
			// information in SBmodelJava
//			System.out.println("Unit type => "+ selected);
			switch(sourceJCB.getSelectedIndex()) {
			case 0 :	parentJP.setUnitType(destination, "amount");
						break;
			case 1 :	parentJP.setUnitType(destination, "concentration");
						break;
			}
		}
	}
}
