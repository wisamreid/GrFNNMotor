package SBexportSBMLGUI;
/* WindowClosingAdapter.java */

import java.awt.event.*;

public class WindowClosingAdapter extends WindowAdapter {
	
	private boolean exitSystem;

	/*
	 * Creates a WindowClosingAdapter to close this frame.
	 * If exitSystem is true, the complete application
	 * will be closed.
	 */
	public WindowClosingAdapter(boolean exitSystem) {
		this.exitSystem = exitSystem;
	}
	
	/*
	 * Creates a WindowClosingAdapter to close this frame.
	 * The complete application will NOT be closed.
	 */
	public WindowClosingAdapter() {
		this(true);
	}
	
	public void windowClosing(WindowEvent event) {
		event.getWindow().setVisible(false);
		event.getWindow().dispose();
		//if (exitSystem) System.exit(0);
	}

}