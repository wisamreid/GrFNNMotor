package SBexportSBMLGUI.dialogs;
/**************************************************************************
 * HelpJTextAreaJDialog: Opens a JDialog frame and prints a help text
 *                       dependend on the choosen Menu ITem from 
 *                       GUIJMenuBar-
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import SBexportSBMLGUI.enums.InfoMessage;

public class Warning extends JDialog implements ActionListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 11);
	private JButton okButton;
	
	private static final int dialogWidth = 400;
	private static final int dialogHeight = 200;
	
	public Warning(JFrame owner, InfoMessage message, String additional) {
		
		super(owner, null, false);
		init(message, additional);
	}
	
	public Warning(JFrame owner, InfoMessage message) {
		
		super(owner, null, false);
		init(message, "");
	}
	
	public Warning(JDialog owner, InfoMessage message) {
		
		super(owner, null, false);
		init(message, "");
	}
		
	private void init(InfoMessage message, String moreText) {
		setTitle("Warning");
		
		if (moreText.equals("")) {
			setSize(dialogWidth, dialogHeight);
		} else {
			int lines = (moreText.length() / 60);
			setSize(dialogWidth, (dialogHeight+lines*10));
		}
		setLocation(300,300);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		JPanel panel = new JPanel(null);
		JTextArea messageArea = new JTextArea();
		messageArea.setEditable(false);
		messageArea.setOpaque(false);
		messageArea.setLineWrap(true);
		messageArea.setWrapStyleWord(true);
		if (moreText.equals("")) {
			messageArea.setText(message.toString());
		} else {
			String newMessage = message.toString() + "\n Compartment relationships: \n" + moreText;
			messageArea.setText(newMessage);
		}
			
		
		messageArea.setBounds(20, 20, dialogWidth-40, dialogHeight-40);
		messageArea.setFont(font);
		panel.add(messageArea);
		panel.setBounds(0, 0, dialogWidth-20, dialogHeight-20);
		
		cp.add("Center", panel);
		
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		okButton = new JButton("Ok");
		okButton.addActionListener(this);
		buttonPanel.add(okButton);
		cp.add("South", buttonPanel);
		
	}
	
	public void actionPerformed(ActionEvent event) {
		JButton source = (JButton)event.getSource();
		if (source == okButton) {
			this.setVisible(false);
			this.dispose();
		}
	}
	
}