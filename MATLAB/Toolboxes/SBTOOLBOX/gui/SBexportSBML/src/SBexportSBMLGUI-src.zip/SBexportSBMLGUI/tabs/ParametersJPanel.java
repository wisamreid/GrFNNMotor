package SBexportSBMLGUI.tabs;

/**************************************************************************
 * ParameterJPanel: creates a JPanel containing all adjustable elements
 *                  that are needed to help to convert the SBmodel
 *                  Parameters to fit into a SBML file.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;

import javax.swing.JLabel;
import javax.swing.JPanel;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.elements.*;
import auxiliary.javamodel.*;

public class ParametersJPanel extends SBmodelGenericJPanel {
	
	GridBagLayout gbl;
	GridBagConstraints gbc;
	
	public ParametersJPanel(SBmodelJava sbmj) {
		// connects the settings made in this dialog with the right fields
		// in the SBmodel Java
		setSBmodelContext(SBmodelContextType.PARAMETER);
		this.sbmj=sbmj;
		initializeSelectionCheckBoxes();
		gbl = new GridBagLayout();
		setLayout(gbl);
		
		/*
		 * Set the Layout for the JPanel.
		 * If there are no parameters print Message!
		 */
		if (sbmj.getNumberOfParameters()==0) {
			setLayout(new FlowLayout());
			JLabel noParameters = new JLabel("SBmodel: \""+sbmj.getName()+"\" contains no parameters.");
			noParameters.setFont(new Font("SansSerif", Font.BOLD, 20));
			add(noParameters);
		} else {
			/*
			 * SBmodel contains parameters!
			 * Set the Layout for the JPanel and print the column heads for all
			 * attributes of SBmodel parameters!
			 */
//			 leave space for selection checkbox
			ColumnHeadJPanel selectionHeading = new ColumnHeadJPanel("");
			gbc = setGBC(0, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionHeading, gbc);
			add(selectionHeading);
			
			ColumnHeadJPanel parameterName = new ColumnHeadJPanel("Parameter Name");
			gbc = setGBC(1, 0, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(parameterName, gbc);
			add(parameterName);
			
			ColumnHeadJPanel parameterValue = new ColumnHeadJPanel("Value");
			gbc = setGBC(3, 0, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(parameterValue, gbc);
			add(parameterValue);
			
			ColumnHeadJPanel parameterType = new ColumnHeadJPanel("SBML Type");
			gbc = setGBC(4, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(parameterType, gbc);
			add(parameterType);
			
			ColumnHeadJPanel specieUnitType = new ColumnHeadJPanel("Unit Type");
			gbc = setGBC(7, 0, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(specieUnitType, gbc);
			add(specieUnitType);
			
			ColumnHeadJPanel parameterCompartment = new ColumnHeadJPanel("Compartment");
			gbc = setGBC(10, 0, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(parameterCompartment, gbc);
			add(parameterCompartment);
			
			ColumnHeadJPanel parameterNotes = new ColumnHeadJPanel("Notes");
			gbc = setGBC(13, 0, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(parameterNotes, gbc);
			add(parameterNotes);
		}
		
		/* 
		 * Place all items for each SBmodel paramter in one row (repeat for all parameters).
		 * 1. JLabel Parameter Name
		 * 2. JTextField Parameter Value
		 * 3. JComboBox SBML Type (choose specie, parameter, variable or compartment)
		 * 4. JComboBox Unit Type (if SBML Type -> specie : choose amount or concentration
		 * 5. JComboBox Compartment (choose to which compartment the state belongs)
		 * 6. JButton Notes calls JDialog with editable JTextArea for notes
		 */
		int parameterscount=sbmj.getNumberOfParameters();
		for (int i=0; i<parameterscount; i++) {
			int parameterIndex=i;
			int gridy=i+1;
			JPanel selectionPanel = new JPanel();
			selectionPanel.add(selectionCheckBoxes.get(parameterIndex));
			gbc = setGBC(0, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(selectionPanel, gbc);
			add(selectionPanel);
			
			ComponentNameJPanel componentNameJP = new ComponentNameJPanel(sbmj.getParameter(parameterIndex).getName()); 
			gbc = setGBC(1, gridy, 2, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(componentNameJP, gbc);
			add(componentNameJP);
			
			ComponentValueJPanel valueJP = new ComponentValueJPanel(parameterIndex, sbmj.getParameter(parameterIndex).getValue());
			gbc = setGBC(3, gridy, 1, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(valueJP, gbc);
			add(valueJP);
			
			/*
			 * Create the JComboBoxes for the choice of the unit type first and then for
			 * the SBML type, afterards add them to the JPanel.
			 * This is necessary because the functionality of the unit type JComboBox changes
			 * accordingly to the selected item of the SBML type JComboBox.
			 * So we have to provide the instances of unit type JPanel and unit type ItemListener
			 * to SBML type JPanel!
			 */
			
			UnitTypeJPanel unitTypeJP = new UnitTypeJPanel(parameterIndex, sbmj.getParameter(parameterIndex).getUnitType(), sbmj.getParameter(parameterIndex).getType());
			gbc = setGBC(7, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(unitTypeJP, gbc);
			add(unitTypeJP);
			
			CompartmentJPanel compartmentJP = new CompartmentJPanel(parameterIndex, sbmj.getParameter(parameterIndex).getName(), sbmj.getParameter(parameterIndex).getCompartment(), sbmj.getParameter(parameterIndex).getType(), sbmj.getCompartments());
			gbc = setGBC(10, gridy, 3, 1, GridBagConstraints.HORIZONTAL);
			gbl.setConstraints(compartmentJP, gbc);
			add(compartmentJP);
			
			SBMLTypeJPanel sbmlTypeJP = new SBMLTypeJPanel(parameterIndex, sbmj.getParameter(parameterIndex).getType(), unitTypeJP, compartmentJP);
			gbc = setGBC(4, gridy, 3, 1, GridBagConstraints.NONE);
			gbl.setConstraints(sbmlTypeJP, gbc);
			add(sbmlTypeJP);
			
			GenericJButtonJPanel notesCBJP = new GenericJButtonJPanel(parameterIndex, TriggerSource.NOTES);  
			gbc = setGBC(13, gridy, 1, 1, GridBagConstraints.NONE);
			gbl.setConstraints(notesCBJP, gbc);
			add(notesCBJP);
			
		}
	}
}
