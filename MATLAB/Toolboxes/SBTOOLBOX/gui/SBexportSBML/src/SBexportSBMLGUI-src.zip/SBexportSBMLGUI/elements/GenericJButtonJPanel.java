package SBexportSBMLGUI.elements;

/**************************************************************************
 * GenericJButtonJPanel: creates a JPanel containing a button by which the
 *                       corresponding JDialog can be opened.
 *                       The button name is used to get the specific
 *                       component the information will be assigned to
 *                       (ODE RHS, Formula, ..., Notes). 
 *                       To react on pressing the button the GenericJButton-
 *                       ActionListener is registered. 
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JButton;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;
import SBexportSBMLGUI.listener.*;

public class GenericJButtonJPanel extends SBmodelGenericJPanel {
	
	public GenericJButtonJPanel(int sbmIndex, TriggerSource trigger) {
		
		JButton genericButton = new JButton(trigger.toString());
		GenericJButtonActionListener cbAL = new GenericJButtonActionListener(sbmIndex, trigger);
		genericButton.setHorizontalAlignment(JButton.CENTER);
		genericButton.setName(String.valueOf(sbmIndex));
		genericButton.addActionListener(cbAL);
		add(genericButton);
		
	}

}
