package SBexportSBMLGUI.menu;
/**************************************************************************
 * GUIJMenuBar: Contains a help menu which is used within the main frame
 *              of SBexportSBMLGUI.
 *              It grants access to help text files for each section of 
 *              the interface (General help, States help, Parameter Help,
 *              Variables help, ...)
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.dialogs.HelpTextArea;
import SBexportSBMLGUI.enums.HelpMessage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUIJMenuBar extends JMenuBar implements ActionListener {
	
	public GUIJMenuBar() {
		JMenu m;
		JMenuItem mi;
		
		/*
		 * This loop runs through the array containing the menu item names.
		 * The menu items are added to the menu/menubar and an ActionListener is
		 * registrated to this particular item, which reacts if the item is selected.
		 */
		m = new JMenu("Help");
		HelpMessage[] miNames = HelpMessage.values();
		for (int i=0; i<miNames.length; i++) {
			mi = new JMenuItem(miNames[i].getMenuItem());
			mi.addActionListener(this);
			m.add(mi);
			if ((i==0) || (i==6)) m.addSeparator();
		}
		add(m);
	}
	
	/*
	 * If a Menu Item is selected open a JDialog containig the appropriate
	 * help text.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		SB2SBMLGUI owner = (SB2SBMLGUI) this.getTopLevelAncestor();
		String cmd = e.getActionCommand();
		if (cmd.equals("General")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.GENERAL);
			helpJD.setVisible(true);
		}
		if (cmd.equals("States")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.STATES_HELP);
			helpJD.setVisible(true);
		}
		if (cmd.equals("Parameters")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.PARAMETERS_HELP);
			helpJD.setVisible(true);
		}
		if (cmd.equals("Variables")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.VARIABLES_HELP);
			helpJD.setVisible(true);
		}
		if (cmd.equals("Reactions")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.REACTIONS_HELP);
			helpJD.setVisible(true);			
		}
		if (cmd.equals("Functions")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.FUNCTIONS_HELP);
			helpJD.setVisible(true);			
		}
		if (cmd.equals("Events")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.EVENTS_HELP);
			helpJD.setVisible(true);
		}
		if (cmd.equals("About")) {
			HelpTextArea helpJD = new HelpTextArea(owner, HelpMessage.ABOUT);
			helpJD.setVisible(true);
		}
	}
}
