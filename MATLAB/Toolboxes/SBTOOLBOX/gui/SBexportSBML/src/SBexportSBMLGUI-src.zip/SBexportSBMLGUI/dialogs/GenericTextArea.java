package SBexportSBMLGUI.dialogs;

/**************************************************************************
 * GenericJButtonJPanel: creates a JDialog containing the information which
 *                       are stored in the corresponding fields of the
 *                       SBmodelJava.
 *                       The buttons "OK" and "Cancel" serve the ability to
 *                       save changed data or to quit the JDialog without
 *                       altering the data within the SBmodelJava.
 *                       To react on pressing the buttons a local
 *                       ActionListener is registered.
 *                       The point where to store the information is 
 *                       solved through the parameter "parent" or "owner"
 *                       from the constructor of this class.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.enums.TriggerSource;

import java.awt.*;
import java.awt.event.*;

public class GenericTextArea extends JDialog implements ActionListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 11);
	
	private TriggerSource trigger;
	private JButton okButton, cancelButton;
	private int sbmIndex;
	private JTextArea componentTextArea;
	private SBmodelGenericJPanel parent;
	private SB2SBMLGUI owner;
	
	/*
	 * This constructor of the JDialog is used to open a JDialog conaining a
	 * JTextArea for the "SBmodel Notes".
	 */
	public GenericTextArea(SB2SBMLGUI owner, TriggerSource trigger) {
		this(owner, null, TriggerSource.SBM_NOTES, -1);
	}
	
	/*
	 * This constructor of the JDialog is used to open a JDialog conaining a
	 * JTextArea for the JButton of all the tabs used within "SBexportSBMLGUI".
	 */
	public GenericTextArea(SB2SBMLGUI owner, SBmodelGenericJPanel parent, TriggerSource trigger, int index) {
		
		super(owner, trigger.toString(), true);
		this.parent = parent;
		this.owner = owner;
		this.trigger = trigger;
		this.sbmIndex=index;
		
		setSize(300, 200);
		setLocation(200,150);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		/*
		 * Print out a JLabel with information to which component this
		 * JTextArea belongs and add it to the JDialog.
		 */
		JPanel contentJPanel = new JPanel();
		contentJPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		String labelString = null;
		if (trigger.equals(TriggerSource.SBM_NOTES)) labelString = "SBmodel: SBmodel Notes"; 
		else labelString = "SBmodel: "+parent.getCurrentItem(index);
		JLabel contentJL = new JLabel(labelString);
		contentJL.setHorizontalAlignment(JLabel.LEFT);
		contentJL.setFont(font);
		contentJPanel.add(contentJL);
		cp.add("North", contentJPanel);
		
		/*
		 * Corresponding to the name of the calling JButton name create
		 * a JTextArea with supplied data from the SBmodelJava, place it
		 * on a JScrollpane and add it to the JDialog. 
		 */
		componentTextArea = new JTextArea();
		componentTextArea.setLineWrap(true);
		componentTextArea.setWrapStyleWord(true);
		switch(trigger) {
		case SBM_NOTES : 
			{
				componentTextArea.setText(owner.getSBMJNotes());
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		case NOTES : 
			{
				componentTextArea.setText(parent.getNotes(index));
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		case ODE_RHS : 
			{
				componentTextArea.setText(parent.getODE(index));
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		case FORMULA : 
			{
				componentTextArea.setText(parent.getFormula(index));
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		case ARGUMENTS : 
			{
				componentTextArea.setText(parent.getArguments(index));
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		case TRIGGER : 
			{
				componentTextArea.setText(parent.getTrigger(index));
				componentTextArea.setSize(getSize().height, getSize().width);
			}
			break;
		}
		
		JScrollPane jsp = new JScrollPane(componentTextArea);
		cp.add("Center", jsp);
		
		/*
		 * Create the JButtons "OK" and "Cancel".
		 * Register local ActionListener and add them to the JDialog.
		 */
		JPanel cmdJPanel = new JPanel();
		cmdJPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		okButton = new JButton("OK");
		okButton.addActionListener(this);
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		cmdJPanel.add(okButton);
		cmdJPanel.add(cancelButton);
		cp.add("South", cmdJPanel);
		
	}
	
	/*
	 * Define what to do if the "OK" or the "Cancel" JButton is pressed.
	 * Test which component is shown in the JTextArea (through title).
	 * If "OK" is pressed, save changes to the specific field of the
	 * SBmodelJava and exit JDialog.
	 * If "Cancel" is pressed, leave JDialog without saving changes.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		
		JButton source = (JButton)e.getSource();
		if (source == okButton) {
			switch(trigger) {
			case SBM_NOTES : owner.setSBMJNotes(componentTextArea.getText()); break;
			case NOTES : parent.setNotes(sbmIndex, componentTextArea.getText()); break;
			case ODE_RHS : parent.setODE(sbmIndex, componentTextArea.getText()); break;
			case FORMULA : parent.setFormula(sbmIndex, componentTextArea.getText()); break;
			case ARGUMENTS : parent.setArguments(sbmIndex, componentTextArea.getText()); break;
			case TRIGGER : parent.setTrigger(sbmIndex, componentTextArea.getText()); break;			
			}
			this.setVisible(false);
			this.dispose();
		} else if (source == cancelButton) {
			this.setVisible(false);
			this.dispose();
		}
	}

}
