package SBexportSBMLGUI.enums;

public enum DecisionMessage {
	
	/*
	 * Messages with YES and NO button.
	 */
	ADD_DEFAULT_COMPARTMENT("For the export of the SBmodel it is necessary " + 
					"that there exists one compartment containing all the " +
					"other components!\nThis problem can easily be resolved by adding one " +
					"compartment as parameter with a size of 1. For doing this please " +
					"click YES!\nAnyway if you want to fix this on your own " +
					"click NO!"),
	
	TOO_MANY_ROOT_COMPARTMENTS("You have defined too many root compartments!\n" +
			"SBML supports only one root/outside compartment. Please check the tabs States, Parameters and " +
			"Variables. If the model is correct it is necessary to define a new compartment that stores all other compartments and unassigned species. " + 
			"This can be done automatically!\n" +
			"Expand model automatically and add therefor default compartment?");
	
	private String decisionMessage;
	
	private DecisionMessage(String decisionMessage) {
		this.decisionMessage = decisionMessage;
	}
	
	public String toString() {
		return decisionMessage;
	}

}
