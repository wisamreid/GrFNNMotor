package SBexportSBMLGUI.dialogs;
/**************************************************************************
 * HelpJTextAreaJDialog: Opens a JDialog frame and prints a help text
 *                       dependend on the choosen Menu ITem from 
 *                       GUIJMenuBar-
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import auxiliary.javamodel.enums.SbmlType;
import auxiliary.javamodel.SBmodelJava;
import auxiliary.javamodel.SBmodelTools;
import SBexportSBMLGUI.*;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RemoveComponent extends JDialog implements ActionListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 11);
	private JButton yesButton, noButton;
	
	private static final int dialogWidth = 300;
	private static final int dialogHeight = 100;
	
	private static final String startStr = "<HTML>Are you sure to remove the ";
	private static final String endStr = "\" ?</HTML>";
	
	private SB2SBMLGUI owner;
	private SBmodelJava sbmj;
	private SBmodelContextType contextType;
	private int index;
	
	public RemoveComponent(SB2SBMLGUI owner, SBmodelContextType contextType, SBmodelJava sbmj, int index) {
		
		super(owner, null, false);
		
		setTitle("Remove "+contextType.toString()+" Dialog");
		this.owner = owner;
		this.sbmj = sbmj;
		this.contextType = contextType;
		this.index = index;
		
		setSize(dialogWidth, dialogHeight);
		setLocation(300,300);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(null);
		centerPanel.setBounds(0, 10, 280, 100);
		
		String componentName = "";
		switch(contextType) {
		case STATE : componentName=sbmj.getState(index).getName(); break;
		case PARAMETER : componentName=sbmj.getParameter(index).getName(); break;
		case VARIABLE : componentName=sbmj.getVariable(index).getName(); break;
		case REACTION : componentName=sbmj.getReaction(index).getName(); break;
		case EVENT : componentName=sbmj.getEvent(index).getName(); break;
		case FUNCTION : componentName=sbmj.getFunction(index).getName(); break;
		}
		JLabel infoLabel = new JLabel(startStr+"<br> "+contextType.toString().toLowerCase()+" \""+componentName+endStr);
		infoLabel.setFont(font);
		double infoLabelWidth = ((Dimension)infoLabel.getPreferredSize()).getWidth();
		infoLabel.setBounds((int)((dialogWidth-infoLabelWidth)/2), 0, (int)infoLabelWidth, 40);
		
		centerPanel.add(infoLabel);
		
		cp.add("Center", centerPanel);
		
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		yesButton = new JButton("Yes");
		yesButton.addActionListener(this);
		buttonPanel.add(yesButton);
		noButton = new JButton("No");
		noButton.addActionListener(this);
		buttonPanel.add(noButton);
		
		cp.add("South", buttonPanel);
		
	}
	
	public void actionPerformed(ActionEvent event) {
		JButton source = (JButton)event.getSource();
		if (source == yesButton) {
			switch(contextType) {
			case STATE : 
				{
				boolean compartment = false;
				String componentName = sbmj.getState(index).getName();
				if (sbmj.getState(index).getType().equals(SbmlType.COMPARTMENT)) compartment = true;
				sbmj.removeState(index);
				if (compartment) {
					SBmodelTools.checkForRemovedCompartment(sbmj, componentName);
					sbmj.makeCompartmentList();
					owner.updateTab(SBmodelContextType.STATE);
					owner.updateTab(SBmodelContextType.PARAMETER);
					owner.updateTab(SBmodelContextType.VARIABLE);
				}
				break;
				}
			case PARAMETER : 
				{
				boolean compartment = false;
				String componentName = sbmj.getParameter(index).getName();
				if (sbmj.getParameter(index).getType().equals(SbmlType.COMPARTMENT)) compartment = true;
				sbmj.removeParameter(index);
				if (compartment) {
					SBmodelTools.checkForRemovedCompartment(sbmj, componentName);
					sbmj.makeCompartmentList();
					owner.updateTab(SBmodelContextType.STATE);
					owner.updateTab(SBmodelContextType.PARAMETER);
					owner.updateTab(SBmodelContextType.VARIABLE);
				}
				break;
				}
			case VARIABLE : 
				{
				boolean compartment = false;
				String componentName = sbmj.getVariable(index).getName();
				if (sbmj.getVariable(index).getType().equals(SbmlType.COMPARTMENT)) compartment = true;
				sbmj.removeVariable(index);
				if (compartment) {
					SBmodelTools.checkForRemovedCompartment(sbmj, componentName);
					sbmj.makeCompartmentList();
					owner.updateTab(SBmodelContextType.STATE);
					owner.updateTab(SBmodelContextType.PARAMETER);
					owner.updateTab(SBmodelContextType.VARIABLE);
				}
				break;
				}
			case REACTION : sbmj.removeReaction(index); break;
			case EVENT : sbmj.removeEvent(index); break;
			case FUNCTION : sbmj.removeFunction(index); break;
			}
			owner.updateTab(contextType);
			this.setVisible(false);
			this.dispose();
		} else if (source == noButton) {
			this.setVisible(false);
			this.dispose();
		}
	}
	
}
