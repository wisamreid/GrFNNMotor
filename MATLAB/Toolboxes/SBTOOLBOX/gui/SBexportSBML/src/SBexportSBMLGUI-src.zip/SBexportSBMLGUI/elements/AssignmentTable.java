package SBexportSBMLGUI.elements;

import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import auxiliary.javamodel.SBmodelEventAssignment;

public class AssignmentTable {
	
	private Font font = new Font("SansSerif", Font.PLAIN, 11);
	private Font headerFont = new Font("SansSerif", Font.BOLD, 11);
	
	private final int INITIAL_ROWHEIGHT = 20;
	
	// table header
	private final String[]tableHeader = {"No.", "Variable", "Formula"};
	
	private ArrayList<SBmodelEventAssignment> assignments;
	
	JTable tableView;
	JScrollPane scrollpane;
	
	JTextField  headerTextField;
	JTextField  footerTextField;
	
	public AssignmentTable() {
		assignments = new ArrayList<SBmodelEventAssignment>();
//		 Create a model of the data.
		TableModel dataModel = new AbstractTableModel() {
			
			public int getColumnCount() { return tableHeader.length; }
			
			public int getRowCount() { return assignments.size();}
			
			public Object getValueAt(int row, int col) {
				if (col == 0) {
					return (row+1);
				} else if (col == 1) {
					return assignments.get(row).getVariable();
				} else if (col == 2) {
					return assignments.get(row).getFormula();
				}
				return null;
			}
			
			public String getColumnName(int col) { return tableHeader[col]; }
			
			public Class getColumnClass(int col) {
				if (col == 0) {
					return Integer.class;
				} else return String.class;
			}
			
			public boolean isCellEditable(int row, int col) {return col!=0;}
			
			public void setValueAt(Object aValue, int row, int col) {
				if (col == 1) {
					assignments.get(row).setVariable(aValue.toString());
				} else if (col == 2) {
					assignments.get(row).setFormula(aValue.toString());
				}
			}
		};
		
		// Create the table
		tableView = new JTable(dataModel);
		
		tableView.setFont(font);
		tableView.setRowHeight(INITIAL_ROWHEIGHT);
		// set the font for the table header
		tableView.getTableHeader().setFont(headerFont);
		
		DefaultTableCellRenderer defaultRenderer = new DefaultTableCellRenderer();
		defaultRenderer.setHorizontalAlignment(JLabel.CENTER);
		
		TableColumn normalColumn = tableView.getColumn("No.");
		normalColumn.setCellRenderer(defaultRenderer);
		normalColumn.setMaxWidth(60);
		normalColumn.setResizable(false);
		normalColumn = tableView.getColumn("Variable");
		normalColumn.setCellRenderer(defaultRenderer);
		normalColumn.setMaxWidth(120);
		normalColumn = tableView.getColumn("Formula");
		normalColumn.setCellRenderer(defaultRenderer);
		normalColumn.setMaxWidth(120);
		
		tableView.getTableHeader().setReorderingAllowed(false);
		tableView.setRowSelectionAllowed(true);
		tableView.setColumnSelectionAllowed(false);
		tableView.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		scrollpane = new JScrollPane(tableView);
	}
	
	public void addAssignment(SBmodelEventAssignment assignment) {
		SBmodelEventAssignment copy = new SBmodelEventAssignment();
		copy.setVariable(assignment.getVariable());
		copy.setFormula(assignment.getFormula());
		assignments.add(copy);
		tableView.updateUI();
	}
	
	public void removeAssignment() {
		int selectedRow = tableView.getSelectedRow();
		if ((selectedRow!=-1) && (tableView.getRowCount()>0) && (selectedRow<tableView.getRowCount())) {
			assignments.remove(selectedRow);
			tableView.updateUI();
		}
	}
	
	public List<SBmodelEventAssignment> getAssignments() {
		return assignments;
	}
	
	public JScrollPane getTablePanel() {
		return scrollpane;
	}
	
	public boolean isTableRowSelected() {
		if (tableView.getSelectedRowCount()==1) return true;
		else return false;
	}
	
}