package SBexportSBMLGUI.matlab;

import auxiliary.javamodel.SBmodelJava;
import com.mathworks.jmi.Matlab;

public class SBML {
	
	private static Matlab currentSession;
	
	/**
	 * This class causes MATLAB to run the
	 * script that is necessary for SBML output.
	 */
	public static void write2file(SBmodelJava sbmj) {
		currentSession = new Matlab();
		// call "writeSBML" script in Matlab for
		// writing model to SBML file
		try {
			Object functionArgs[] = new Object[1];
			functionArgs[0] = sbmj;
			currentSession.feval("writeSBML", functionArgs);
		} catch ( Exception ex) {
			// check cannot copy filename error when cancel button
			// of save file dialog is pressed
			if (!ex.toString().contains("Cannot copy filename"))
				ex.printStackTrace();
		}
	}

}
