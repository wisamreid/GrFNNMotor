package SBexportSBMLGUI.matlab;

import auxiliary.javamodel.SBmodelJava;
import com.mathworks.jmi.Matlab;

public class JavaModel {
	
	private static Matlab currentSession;
	
	/**
	 * This class causes MATLAB to reconvert the
	 * changed java model to a SBmodel.
	 */
	public static void applyChanges(SBmodelJava sbmj) {
		currentSession = new Matlab();
		// call "applyChanges" script in Matlab for
		// making the changes within the javamodel
		// available as SBmodel
		try {
			currentSession.eval("global changedModel");
			Object functionArgs[] = new Object[1];
			functionArgs[0] = sbmj;
			currentSession.feval("applyChanges", functionArgs);
		} catch ( Exception ex) {
			ex.printStackTrace();
		}	
	}

}
