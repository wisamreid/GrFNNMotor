package SBexportSBMLGUI;

import auxiliary.javamodel.*;

public class TestSBmodel {
	
	private static SBmodelJava test;
	
	public TestSBmodel() {
		if (test==null) {
			test = new SBmodelJava();
		}
		test.setName("Test Titel String");
		test.setNotes("Test Notes String");
		test.setNumberOfStates(2);
		test.getState(0).setName("s1");
		test.getState(1).setName("s2");
		test.getState(0).setInitialCondition(1);
		test.getState(1).setInitialCondition(0);
		test.getState(0).setODE("-R");
		test.getState(1).setODE("+k3*R");
		
		test.setNumberOfParameters(3);
		test.getParameter(0).setName("k1");
		test.getParameter(0).setValue(1);
		test.getParameter(1).setName("k2");
		test.getParameter(1).setValue(2);
		test.getParameter(2).setName("k3");
		test.getParameter(2).setValue(3);
		
		test.setNumberOfReactions(1);
		test.getReaction(0).setName("R");
		test.getReaction(0).setFormula("k1*S1 + k2");
		
		test.setNumberOfEvents(1);
		test.getEvent(0).setName("Event_1");
		test.getEvent(0).setTrigger("lt(S1,0.1)");
		test.getEvent(0).setNumberOfAssignments(2);
		test.getEvent(0).getAssignment(0).setVariable("S1");
		test.getEvent(0).getAssignment(0).setFormula("1");
		test.getEvent(0).getAssignment(1).setVariable("S2");
		test.getEvent(0).getAssignment(1).setFormula("0");
		
		
	}
	
	public SBmodelJava getSBmodel() {
		return test;
	}
	
	public void setSBmodel(SBmodelJava test) {
		this.test = test;
	}

}
