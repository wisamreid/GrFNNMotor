package SBexportSBMLGUI.dialogs;

/**************************************************************************
 * EventsAssignmentJTableJDialog: creates a JDialog containing a JTable
 *                                which holds the information for the
 *                                EventsAssignment (per assignment one field
 *                                for variable and one for a corresponding
 *                                formula).
 *                                After editing a table cell choose another
 *                                or press ENTER to apply the changes to the
 *                                JTable.
 *                                The buttons "OK" and "Cancel" serve the
 *                                ability to save changed data or to quit
 *                                the JDialog without altering the data
 *                                within the SBmodelJava.
 *                                To react on pressing the buttons a local
 *                                ActionListener is registered.
 *                                The point where to store the information
 *                                is solved through the parameter "parent"
 *                                or "owner" from the constructor of this
 *                                class.
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import SBexportSBMLGUI.*;
import SBexportSBMLGUI.elements.AssignmentTable;
import SBexportSBMLGUI.enums.InfoMessage;
import SBexportSBMLGUI.enums.TriggerSource;

import auxiliary.javamodel.SBmodelEventAssignment;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.util.List;

public class EventsAssignmentTable extends JDialog implements ActionListener {
	
	private Font font = new Font("SansSerif", Font.BOLD, 12);
	
	private TriggerSource trigger;
	private int index;
	private JButton okButton, cancelButton;
	private JButton addRow, removeRow;
//	private JTable assignmentTable;
	private AssignmentTable assignmentTable;
	SBmodelGenericJPanel parent;
	SB2SBMLGUI owner;
	
	public EventsAssignmentTable(SB2SBMLGUI owner, SBmodelGenericJPanel parent, TriggerSource trigger, int index) {
		
		super(owner, trigger.toString(), true);
		this.parent = parent;
		this.trigger = trigger;
		this.index=index;
		
		setSize(300, 200);
		setLocation(200,150);
		
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		
		/*
		 * Print out a JLabel with information to which component this
		 * JTextArea belongs and add it to the JDialog.
		 */
		JPanel contentJPanel = new JPanel();
		contentJPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		String labelString = "SBmodel: "+parent.getCurrentItem(index);
		JLabel contentJL = new JLabel(labelString);
		contentJL.setHorizontalAlignment(JLabel.LEFT);
		contentJL.setFont(font);
		contentJPanel.add(contentJL);
		cp.add("North", contentJPanel);
		
		/*
		 * Get Information from the SBmodelJava and put them into the JTable.
		 * The JTable is then added to a JScrollPane which is painted to the
		 * JDialog.
		 */
		assignmentTable = new AssignmentTable();
		int eventAssignmentCount = parent.getEvent(index).getNumberOfAssignments();
		for (int i=0; i<eventAssignmentCount; i++) {
			assignmentTable.addAssignment(parent.getEvent(index).getAssignment(i));
		}
		
		addRow = new JButton("Add Row");
		addRow.addActionListener(this);
		removeRow = new JButton("Remove Row");
		removeRow.addActionListener(this);
		JPanel rowButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
		rowButtons.setBorder(BorderFactory.createEtchedBorder());
		rowButtons.add(addRow);
		rowButtons.add(removeRow);
		JPanel assignmentPanel = new JPanel(new BorderLayout());
		assignmentPanel.add("Center", assignmentTable.getTablePanel());
		assignmentPanel.add("South", rowButtons);
		
		cp.add("Center", assignmentPanel);
		
		/*
		 * Create the JButtons "OK" and "Cancel".
		 * Register local ActionListener and add them to the JDialog.
		 */
		JPanel cmdJPanel = new JPanel();
		cmdJPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		cmdJPanel.setBorder(BorderFactory.createEtchedBorder());
		okButton = new JButton("OK");
		okButton.addActionListener(this);
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		cmdJPanel.add(okButton);
		cmdJPanel.add(cancelButton);
		cp.add("South", cmdJPanel);
		
	}
	
	/*
	 * Define what to do if the "OK" or the "Cancel" JButton is pressed.
	 * If "OK" is pressed, save changes to the specific field of the
	 * SBmodelJava and exit JDialog.
	 * If "Cancel" is pressed, leave JDialog without saving changes.
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		
		JButton source = (JButton)e.getSource();
		if (source == cancelButton) {
			this.setVisible(false);
			this.dispose();
		} else if (source == okButton) {
			List<SBmodelEventAssignment> assignmentList = assignmentTable.getAssignments();
			parent.getEvent(index).setNumberOfAssignments(assignmentList.size());
			int indexCounter=0;
			for (SBmodelEventAssignment assignment : assignmentList) {
				parent.getEvent(index).setAssignment(indexCounter++, assignment);
			}
			this.setVisible(false);
			this.dispose();
		} else if (source == addRow) {
			// add a new assignment to the end of the table
			assignmentTable.addAssignment(new SBmodelEventAssignment());
		} else if (source == removeRow) {
			// remove the assignment at the selected row within the table
			if (assignmentTable.isTableRowSelected()) {
				assignmentTable.removeAssignment();
			} else {
				JDialog warning = new Warning(this, InfoMessage.NO_SELECTION_FOR_REMOVE_ASSIGNMENT);
				warning.setVisible(true);
			}
		}
	}

}
