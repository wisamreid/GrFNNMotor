package SBexportSBMLGUI.elements;

/**************************************************************************
 * SBMLTypeJPanel: creates a JPanel containing a JComboBox containing
 *                 the items "Specie", "Parameter", "Variable" and 
 *                 "Compartment" which can be choosen.
 *                 To observe state changes register a SBMLTypeItemListener!
 *               
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.JComboBox;

import auxiliary.javamodel.enums.*;
import SBexportSBMLGUI.*;
import SBexportSBMLGUI.listener.*;

public class SBMLTypeJPanel extends SBmodelGenericJPanel {
	
	public SBMLTypeJPanel(int sbmIndex, SbmlType preselect, UnitTypeJPanel utJP, CompartmentJPanel compJP) {
		/*
		 * Instantiation of the JComboBox and set the index
		 * (No. of state, parameter...) as name.
		 */
		JComboBox sbmlType = new JComboBox(SbmlType.values());
		sbmlType.removeItemAt(3);
		sbmlType.setName(String.valueOf(sbmIndex));
		
		/*
		 * Test wether there is an input value for the state type.
		 * If yes, apply it to the JComboBox!
		 * If no, apply "isSpecie" by default and print warning!
		 * (only for security reasons; default values should be assigned through MATLAB)
		 */
		switch(preselect) {
		case SPECIE : sbmlType.setSelectedIndex(0); break;
		case PARAMETER : sbmlType.setSelectedIndex(1); break;
		case COMPARTMENT : sbmlType.setSelectedIndex(2); break;
		case NONE :
			SBmodelGenericJPanel help = (SBmodelGenericJPanel) utJP.getParent();
//			System.out.println("WARNING: supplied SBmodel contains no predefined SBML type for "+ help.getSBmodelContext() +" no.:"+(sbmIndex+1)+" !!!");
			if (help.getSBmodelContext().equals(SBmodelContextType.PARAMETER)) {
//				System.out.println("SBML type set to SBML Parameter by default.");
				sbmlType.setSelectedIndex(1);
				help.setSBMLType(sbmIndex, "isParameter");
				help.setUnitType(sbmIndex, "");
				utJP.getUnitTypeJCB().removeAllItems();
				utJP.getUnitTypeJCB().setEnabled(false);
				help.setCompartment(sbmIndex, "");
				compJP.getCompartmentJCB().removeAllItems();
				compJP.getCompartmentJCB().addItem("");
				compJP.getCompartmentJCB().setEnabled(false);
			} else {
//				System.out.println("SBML type set to SBML Specie by default.");
				sbmlType.setSelectedIndex(0);
				help.setSBMLType(sbmIndex, "isSpecie");
				help.setUnitType(sbmIndex, "amount");
			} break;
		}
		
		/*
		 * Add ItemListener to the JComboBox which reacts on changes.
		 * The ItemListener gets the instances of the unit type JPanel and ItemListener,
		 * because it has to change the properties of them.
		 * (unit type JComboBox is only needed if SBML type is "isSpecie")
		 * Add the JComboBox to the JPanel of this class.
		 */
		SBMLTypeItemListener sbmlTypeIL = new SBMLTypeItemListener(utJP, compJP);
		sbmlType.addItemListener(sbmlTypeIL);
		add(sbmlType);
	}

}
