package auxiliary.javamodel;

/**************************************************************************
 * SBmodelEventAssignment: representation of the "events.assignment" branch
 *                         from the SBmodel. For attibute access get and
 *                         set methods were made available.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/
/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

public class SBmodelEventAssignment {
	
	private String variable;
	private String formula;
	
	public String getVariable() {
		return variable;
	}
	
	public void setVariable(String variable) {
		this.variable=variable;
	}
	
	public String getFormula() {
		return formula;
	}
	
	public void setFormula(String formula) {
		this.formula=formula;
	}
	
	public SBmodelEventAssignment makeCopy() {
		SBmodelEventAssignment copy = new SBmodelEventAssignment();
		copy.setVariable(variable);
		copy.setFormula(formula);
		return copy;
	}

}
