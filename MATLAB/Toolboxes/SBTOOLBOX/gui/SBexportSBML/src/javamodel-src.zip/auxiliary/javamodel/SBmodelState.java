package auxiliary.javamodel;

/**************************************************************************
 * SBmodelStates: representation of the "states" branch from the SBmodel.
 *                For attibute access get and set methods were made
 *                available.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import auxiliary.javamodel.enums.SbmlSpecieUnitType;
import auxiliary.javamodel.enums.SbmlType;

public class SBmodelState {
	
	private String name;
	private double initialCondition;
	private String ODE;
	private SbmlType type;
	private SbmlSpecieUnitType unitType;
	private String compartment;
	private String notes;
	
	public SBmodelState() {
		this(null);
	}
	
	public SBmodelState(String name) {
		this.name = name;
		type = SbmlType.NONE;
		unitType = SbmlSpecieUnitType.NONE;
		compartment = "";
	}
		
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
		
	public double getInitialCondition() {
		return initialCondition;
	}
		
	public void setInitialCondition(double iniCond) {
		this.initialCondition = iniCond;
	}
	
	public String getODE() {
		return ODE;
	}
	
	public void setODE(String ode) {
		this.ODE = ode;
	}
	
	public SbmlType getType() {
		return type;
	}
	
	public void setType(SbmlType type) {
		this.type = type;
	}
	
	public void setType(String sbToolboxExpression) {
		this.type = SbmlType.forSBToolboxExpression(sbToolboxExpression);
	}
	
	public SbmlSpecieUnitType getUnitType() {
		return unitType;
	}
	
	public void setUnitType(SbmlSpecieUnitType unitType) {
		this.unitType = unitType;
	}
	
	public void setUnitType(String unitType) {
		this.unitType = SbmlSpecieUnitType.forSBToolboxExpression(unitType);
	}
	
	public String getCompartment() {
		return compartment;
	}
	
	public void setCompartment(String compartment) {
		this.compartment = compartment;
	}
	
	public String getNotes() {
		return notes;
	}
	
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	public SBmodelState makeCopy() {
		SBmodelState copy = new SBmodelState();
		copy.setName(name);
		copy.setInitialCondition(initialCondition);
		copy.setODE(ODE);
		copy.setType(type);
		copy.setUnitType(unitType);
		copy.setCompartment(compartment);
		copy.setNotes(notes);
		return copy;
	}
}