package auxiliary.javamodel.enums;

public enum SbmlSpecieUnitType {
	
	AMOUNT("Amount", "amount"),
	CONCENTRATION("Concentration", "concentration"),
	NONE("", "");
	
	private String sbmlSpecieUnitType;
	private String sbToolboxExpression;
	
	private SbmlSpecieUnitType(String sbmlUnitType, String sbToolboxExpression) {
		this.sbmlSpecieUnitType = sbmlUnitType;
		this.sbToolboxExpression = sbToolboxExpression;
	}
	
	public static SbmlSpecieUnitType forSBToolboxExpression(String sbToolboxExpression) {
		if (sbToolboxExpression.equals(AMOUNT.asSBToolboxExpression())) return AMOUNT;
		if (sbToolboxExpression.equals(CONCENTRATION.asSBToolboxExpression())) return CONCENTRATION;
		if (sbToolboxExpression.equals(NONE.asSBToolboxExpression())) return NONE;
		return NONE;
	}
	
	public String asSbmlSpecieUnitType() {
		return sbmlSpecieUnitType;
	}
	
	public String asSBToolboxExpression() {
		return sbToolboxExpression;
	}
	
	public String toString() {
		return sbmlSpecieUnitType;
	}

}
