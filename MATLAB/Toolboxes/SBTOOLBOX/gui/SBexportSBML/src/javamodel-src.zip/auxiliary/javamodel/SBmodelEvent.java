package auxiliary.javamodel;

/**************************************************************************
 * SBmodelEvents: representation of the "events" branch from the SBmodel.
 *                For attibute access get and set methods were made
 *                available.
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.util.ArrayList;

public class SBmodelEvent {
	
	private String name;
	private String trigger;
	private ArrayList<SBmodelEventAssignment> assignments;
	private String notes;
	
	public SBmodelEvent() {}
	
	public SBmodelEvent(String name) {
		this.name = name;
	}
		
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getTrigger() {
		return trigger;
	}
	
	public void setTrigger(String trigger) {
		this.trigger = trigger;
	}
	
	public int getNumberOfAssignments() {
		try {
			return assignments.size();
		} catch (Exception e) {
			//System.out.println("This event of the SBmodel contains no assignments!");
			return 0;
		}
	}
	
	public void setNumberOfAssignments(int number) {
		assignments = new ArrayList<SBmodelEventAssignment>(number);
		for (int i=0; i<number; i++) {
			assignments.add(i, new SBmodelEventAssignment());
		}
	}
	
	public void addAssignment() {
		if (assignments == null) new ArrayList<SBmodelEventAssignment>();
		assignments.add(new SBmodelEventAssignment());
	}
	
	public SBmodelEventAssignment getAssignment(int index) {
		try {
			return assignments.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing assignment (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeAssignment(int index) {
		try {
			assignments.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no assignments to remove in event \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of assignment (index: "+index+") wasn't possible. SBmodelEventAssignment count: "+getNumberOfAssignments());
		}
	}
	
	public void setAssignment(int index, SBmodelEventAssignment sbmEventAssignment) {
		assignments.get(index).setVariable(sbmEventAssignment.getVariable());
		assignments.get(index).setFormula(sbmEventAssignment.getFormula());
	}
	
	public void setAssignment(int index, Object[] input) {
		assignments.get(index).setVariable(parseMatlabString(input[0]));
		assignments.get(index).setFormula(parseMatlabString(input[1]));
	}
	
	public Object[][] getEventAssignmentArray() {
		int assignmentcount = getNumberOfAssignments();
		Object[][] assignmentarray = new Object[assignmentcount][3];
		for (int i=0; i<assignmentcount; i++) {
			assignmentarray[i][0]=String.valueOf(i);
			assignmentarray[i][1]=assignments.get(i).getVariable();
			assignmentarray[i][2]=assignments.get(i).getFormula();
		}
		return assignmentarray;
	}
	
	public void setEventAssignmentArray(Object[][] array) {
		int assignmentcount = array.length;
		for (int i=0; i<assignmentcount; i++) {
			assignments.get(i).setVariable(array[i][1].toString());
			assignments.get(i).setFormula(array[i][2].toString());
		}
	}
	
	public String getNotes() {
		return notes;
	}
	
	public void setNotes(String notes) {
		this.notes= notes;
	}
	
	public String parseMatlabString(Object obj) {
		String str="";
		try {
			str=obj.toString();
		} catch (Exception e) {
			/* MATLAB Object (string) has been empty, which could lead to an error
			 * and program termination.
			 */ 
		}
		return str;
	}
	
	public double parseMatlabDouble(Object obj) {
		double numeric=0;
		try {
			numeric=Double.parseDouble(obj.toString());
		} catch (Exception e) {
			/* MATLAB Object (numeric) has been empty, which could lead to an error
			 * and program termination.
			 */ 
		}
		return numeric;
	}
	
	public SBmodelEvent makeCopy() {
		SBmodelEvent copy = new SBmodelEvent();
		copy.setName(name);
		copy.setTrigger(trigger);
		int ea = getNumberOfAssignments();
		copy.setNumberOfAssignments(ea);
		for (int i=0; i<ea; i++) {
//			copy.setAssignment(i, this.assignment.get(i).makeCopy());
			copy.assignments.set(i, assignments.get(i).makeCopy());
		}
		copy.setNotes(notes);
		return copy;
	}

}
