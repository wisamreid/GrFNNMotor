package auxiliary.javamodel.enums;

import SBexportSBMLGUI.SBmodelGenericJPanel;

public enum SbmlType {
	
	SPECIE("SBML Specie", "isSpecie"),
	PARAMETER("SBML Parameter", "isParameter"),
	COMPARTMENT("SBML Compartment", "isCompartment"),
	NONE("", "");
	
	private String sbmlType;
	private String sbToolboxExpression;
	
	private SbmlType(String sbmlType, String sbToolboxExpression) {
		this.sbmlType = sbmlType;
		this.sbToolboxExpression = sbToolboxExpression;
	}
	
	public static SbmlType forSBToolboxExpression(String sbToolboxExpression) {
		if (sbToolboxExpression.equals(SPECIE.sbToolboxExpression)) return SPECIE;
		if (sbToolboxExpression.equals(PARAMETER.sbToolboxExpression)) return PARAMETER;
		if (sbToolboxExpression.equals(COMPARTMENT.sbToolboxExpression)) return COMPARTMENT;
		if (sbToolboxExpression.equals("")) return NONE;
		return NONE;
	}
	
	public String asSbmlType() {
		return sbmlType;
	}
	
	public String asSBToolboxExpression() {
		return sbToolboxExpression;
	}
	
	public String toString() {
		return sbmlType;
	}

}
