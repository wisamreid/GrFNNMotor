package auxiliary.javamodel;

/**************************************************************************
 * SBmodelJ: provides a data object which contains all information 
 *           supported by the SBmodel.
 *           For easier access get and set methods as well as methods for
 *           data conversion from MATLAB to Java were made available. 
 *                  
 * @author Gunnar Drews, gunnar.drews@uni-rostock.de
 *         student at University of Rostock Dep. of Computer Science
 **************************************************************************/

/*
 * Information:
 * ============
 * Systems Biology Toolbox for MATLAB
 * Copyright (C) 2005 Henning Schmidt, FCC, henning@fcc.chalmers.se
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 * 
 * You should have received a copy of the GNU General Public License
 * among with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.util.ArrayList;
import java.util.List;

import auxiliary.javamodel.enums.SbmlType;

public class SBmodelJava {
	
	private String name;
	private String notes;

	private ArrayList<SBmodelFunction> functions;
	private ArrayList<SBmodelState> states;
	private ArrayList<SBmodelParameter> parameters;
	private ArrayList<SBmodelVariable> variables;
	private ArrayList<SBmodelReaction> reactions;
	private ArrayList<SBmodelEvent> events;
	private String functionsMATLAB;
	
	private SBmodelJava backup;
	private boolean madeBackup;
	private ArrayList<String> compartmentList;
	
	public SBmodelJava() {
		this.madeBackup = false;
	}
	
	public SBmodelJava getBackup() {
		return backup;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getNotes() {
		return notes;
	}
	
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	public int getNumberOfFunctions() {
		try {
			return functions.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no functions!");
			return 0;
		}
	}
	
	public void setNumberOfFunctions(int number) {
		functions = new ArrayList<SBmodelFunction>(number);
		for (int i=0; i<number; i++) {
			functions.add(i, new SBmodelFunction());
		}
	}
	
	public void addFunction(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A function to add has to have a name! No function has been added.");
		} else {
			if (functions==null) functions = new ArrayList<SBmodelFunction>();
			functions.add(getNumberOfFunctions(), new SBmodelFunction(name));
		}
	}
	
	public SBmodelFunction getFunction(int index) {
		try {
			return functions.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing function (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeFunction(int index) {
		try {
			functions.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no functions to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of function (index: "+index+") wasn't possible. SBmodelFunction count: "+getNumberOfFunctions());
		}
	}
	
	public void renameFunction(int index, String name) {
		try {
			functions.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of function (index: "+index+") wasn't possible.");
		}
	}
	
	public void setFunction(int index, Object[] input) {
		functions.get(index).setName(parseMatlabString(input[0]));
		functions.get(index).setArguments(parseMatlabString(input[1]));
		functions.get(index).setFormula(parseMatlabString(input[2]));
		functions.get(index).setNotes(parseMatlabString(input[3]));
	}
	
	public int getNumberOfStates() {
		try {
			return states.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no states!");
			return 0;
		}
	}
	
	public void setNumberOfStates(int number) {
		states = new ArrayList<SBmodelState>(number);
		for (int i=0; i<number; i++) {
			states.add(i, new SBmodelState());
		}
	}
	
	public void addState(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A state to add has to have a name! No state has been added.");
		} else {
			if (states==null) states = new ArrayList<SBmodelState>();
			states.add(getNumberOfStates(), new SBmodelState(name));
		}
	}
	
	public SBmodelState getState(int index) {
		try {
			return states.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing state (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeState(int index) {
		try {
			states.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no states to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of state (index: "+index+") wasn't possible. SBmodelState count: "+getNumberOfStates());
		}
	}
	
	public void renameState(int index, String name) {
		try {
			states.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of state (index: "+index+") wasn't possible.");
		}
	}
	
	public void setState(int index, Object[] input) {
		states.get(index).setName(parseMatlabString(input[0]));
		states.get(index).setInitialCondition(parseMatlabDouble(input[1]));
		states.get(index).setODE(parseMatlabString(input[2]));
		states.get(index).setType(parseMatlabString(input[3]));
		states.get(index).setCompartment(parseMatlabString(input[4]));
		states.get(index).setUnitType(parseMatlabString(input[5]));
		states.get(index).setNotes(parseMatlabString(input[6]));
	}
	
	public int getNumberOfParameters() {
		try {
			return parameters.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no parameters!");
			return 0;
		}
	}

	public void setNumberOfParameters(int number) {
		parameters = new ArrayList<SBmodelParameter>(number);
		for (int i=0; i<number; i++) {
			parameters.add(i, new SBmodelParameter());
		}
	}
	
	public void addParameter(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A parameter to add has to have a name! No parameter has been added.");
		} else {
			if (parameters==null) parameters = new ArrayList<SBmodelParameter>();
			parameters.add(getNumberOfParameters(), new SBmodelParameter(name));
		}
	}
	
	public SBmodelParameter getParameter(int index) {
		try {
			return parameters.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing parameter (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeParameter(int index) {
		try {
			parameters.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no parameters to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of parameter (index: "+index+") wasn't possible. SBmodelParameter count: "+getNumberOfParameters());
		}
	}
	
	public void renameParameter(int index, String name) {
		try {
			parameters.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of parameter (index: "+index+") wasn't possible.");
		}
	}
	
	public void setParameter(int index, Object[] input) {
		parameters.get(index).setName(parseMatlabString(input[0]));
		parameters.get(index).setValue(parseMatlabDouble(input[1]));
		parameters.get(index).setType(parseMatlabString(input[2]));
		parameters.get(index).setCompartment(parseMatlabString(input[3]));
		parameters.get(index).setUnitType(parseMatlabString(input[4]));
		parameters.get(index).setNotes(parseMatlabString(input[5]));
	}
	
	public int getNumberOfVariables() {
		try {
			return variables.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no variables!");
			return 0;
		}
	}
	
	public void setNumberOfVariables(int number) {
		variables = new ArrayList<SBmodelVariable>(number);
		for (int i=0; i<number; i++) {
			variables.add(i, new SBmodelVariable());
		}
	}
	
	public void addVariable(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A variable to add has to have a name! No variable has been added.");
		} else {
			if (variables==null) variables = new ArrayList<SBmodelVariable>();
			variables.add(getNumberOfVariables(), new SBmodelVariable(name));
		}
	}
	
	public SBmodelVariable getVariable(int index) {
		try {
			return variables.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing variable (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeVariable(int index) {
		try {
			variables.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no variables to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of variable (index: "+index+") wasn't possible. SBmodelVariable count: "+getNumberOfVariables());
		}
	}
	
	public void renameVariable(int index, String name) {
		try {
			variables.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of variable (index: "+index+") wasn't possible.");
		}
	}
	
	public void setVariable(int index, Object[] input) {
		variables.get(index).setName(parseMatlabString(input[0]));
		variables.get(index).setFormula(parseMatlabString(input[1]));
		variables.get(index).setType(parseMatlabString(input[2]));
		variables.get(index).setCompartment(parseMatlabString(input[3]));
		variables.get(index).setUnitType(parseMatlabString(input[4]));
		variables.get(index).setNotes(parseMatlabString(input[5]));
	}
	
	public int getNumberOfReactions() {
		try {
			return reactions.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no reactions!");
			return 0;
		}
	}
	
	public void setNumberOfReactions(int number) {
		reactions = new ArrayList<SBmodelReaction>(number);
		for (int i=0; i<number; i++) {
			reactions.add(i, new SBmodelReaction());
		}
	}
	
	public void addReaction(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A reaction to add has to have a name! No reaction has been added.");
		} else {
			if (reactions==null) reactions = new ArrayList<SBmodelReaction>();
			reactions.add(getNumberOfReactions(), new SBmodelReaction(name));
		}
	}
	
	public SBmodelReaction getReaction(int index) {
		try {
			return reactions.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing reaction (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeReaction(int index) {
		try {
			reactions.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no reactions to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of reaction (index: "+index+") wasn't possible. SBmodelReaction count: "+getNumberOfReactions());
		}
	}
	
	public void renameReaction(int index, String name) {
		try {
			reactions.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of reaction (index: "+index+") wasn't possible.");
		}
	}
	
	public void setReaction(int index, Object[] input) {
		reactions.get(index).setName(parseMatlabString(input[0]));
		reactions.get(index).setFormula(parseMatlabString(input[1]));
		reactions.get(index).setNotes(parseMatlabString(input[2]));
		reactions.get(index).setReversible(parseMatlabDouble(input[3]));
	}
	
	public int getNumberOfEvents() {
		try {
			return events.size();
		} catch (Exception e) {
			//System.out.println("This SBmodel contains no events!");
			return 0;
		}
	}
	
	public void setNumberOfEvents(int number) {
		events = new ArrayList<SBmodelEvent>(number);
		for (int i=0; i<number; i++) {
			events.add(i, new SBmodelEvent());
		}
	}
	
	public void addEvent(String name) {
		if (name.equals("") || (name==null)) {
			System.out.println("WARNING: A event to add has to have a name! No event has been added.");
		} else {
			if (events==null) events = new ArrayList<SBmodelEvent>();
			events.add(getNumberOfEvents(), new SBmodelEvent(name));
		}
	}
	
	public SBmodelEvent getEvent(int index) {
		try {
			return events.get(index);
		} catch (Exception e) {
			System.out.println("WARNING: Access to non-existing event (index: " + index + ") occurred! NULL object returned.");
			return null;
		}
	}
	
	public void removeEvent(int index) {
		try {
			events.remove(index);
		} catch (NullPointerException npEx) {
			System.out.println("ERROR: There are no events to remove in SBmodel \""+name+"\".");
		} catch (Exception Ex) {
			System.out.println("ERROR: Removing of event (index: "+index+") wasn't possible. SBmodelEvent count: "+getNumberOfEvents());
		}
	}
	
	public void renameEvent(int index, String name) {
		try {
			events.get(index).setName(name);
		} catch (Exception Ex) {
			System.out.println("ERROR: Renaming of event (index: "+index+") wasn't possible.");
		}
	}
	
	public void setEvent(int index, Object[] input) {
		events.get(index).setName(parseMatlabString(input[0]));
		events.get(index).setTrigger(parseMatlabString(input[1]));
		events.get(index).setNotes(parseMatlabString(input[3]));
	}
	
	public String getFunctionsMATLAB() {
		return this.functionsMATLAB;
	}
	
	public void setFunctionsMATLAB(String funcMATLAB) {
		this.functionsMATLAB=funcMATLAB;
	}
	
	public int makeCompartmentList() {
		// count all Compartments within the SBmodel Java
		compartmentList = new ArrayList<String>();
		if (getNumberOfStates()>0) {
			for (SBmodelState state : states) {
				if (state.getType().equals(SbmlType.COMPARTMENT))
					compartmentList.add(state.getName()); 
			}
		}
		if (getNumberOfParameters()>0) {
			for (SBmodelParameter parameter : parameters) {
				if (parameter.getType().equals(SbmlType.COMPARTMENT))
					compartmentList.add(parameter.getName());
			}
		}
		if (getNumberOfVariables()>0) {
			for (SBmodelVariable variable : variables) {
				if (variable.getType().equals(SbmlType.COMPARTMENT))
					compartmentList.add(variable.getName());
			}
		}
//		System.out.println("Compartmentlist updated!\nNumber of Compartments in SBmodelJava " + compartmentList.size());
		return compartmentList.size();
	}
	
	public List<String> getCompartments() {
		return compartmentList;
	}
	
	public String parseMatlabString(Object obj) {
		String str="";
		try {
			str=obj.toString();
		} catch (Exception e) {
			/* 
			 * MATLAB Object (string) has been empty, which could lead to an error
			 * and program termination.
			 */ 
		}
		return str;
	}
	
	public double parseMatlabDouble(Object obj) {
		double numeric=0;
		try {
			numeric=Double.parseDouble(obj.toString());
		} catch (Exception e) {
			/* 
			 * MATLAB Object (numeric) has been empty, which could lead to an error
			 * and program termination.
			 */ 
		}
		return numeric;
	}
	
	public SBmodelJava makeCopy() {
		SBmodelJava copy = new SBmodelJava();
		copy.setName(name);
		copy.setNotes(notes);
		int count = getNumberOfFunctions();
		copy.setNumberOfFunctions(count);
		for (int i=0; i<count; i++) {
			copy.functions.set(i, functions.get(i).makeCopy());
		}
		count = getNumberOfStates();
		copy.setNumberOfStates(count);
		for (int i=0; i<count; i++) {
			copy.states.set(i, states.get(i).makeCopy());
		}
		count = getNumberOfParameters();
		copy.setNumberOfParameters(count);
		for (int i=0; i<count; i++) {
			copy.parameters.set(i, parameters.get(i).makeCopy());
		}
		count = getNumberOfVariables();
		copy.setNumberOfVariables(count);
		for (int i=0; i<count; i++) {
			copy.variables.set(i, variables.get(i).makeCopy());
		}
		count = getNumberOfReactions();
		copy.setNumberOfReactions(count);
		for (int i=0; i<count; i++) {
			copy.reactions.set(i, reactions.get(i).makeCopy());
		}
		count = getNumberOfEvents();
		copy.setNumberOfEvents(count);
		for (int i=0; i<count; i++) {
			copy.events.set(i, events.get(i).makeCopy());
		}
		copy.setFunctionsMATLAB(functionsMATLAB);
		return copy;
	}
	
	public void backupSBMJ() {
		backup = makeCopy();
		madeBackup=true;
	}
	
	public boolean madeBackup() {
		return madeBackup;
	}
	
	public void restoreSBMJ() {
		if (madeBackup) {
			setName(backup.getName());
			setNotes(backup.getNotes());
			int count = backup.getNumberOfFunctions();
			setNumberOfFunctions(count);
			for (int i=0; i<count; i++) {
				functions.set(i, backup.functions.get(i).makeCopy());
			}
			count = backup.getNumberOfStates();
			setNumberOfStates(count);
			for (int i=0; i<count; i++) {
				states.set(i, backup.states.get(i).makeCopy());
			}
			count = backup.getNumberOfParameters();
			setNumberOfParameters(count);
			for (int i=0; i<count; i++) {
				parameters.set(i, backup.parameters.get(i).makeCopy());
			}
			count = backup.getNumberOfVariables();
			setNumberOfVariables(count);
			for (int i=0; i<count; i++) {
				variables.set(i, backup.variables.get(i).makeCopy());
			}
			count = backup.getNumberOfReactions();
			setNumberOfReactions(count);
			for (int i=0; i<count; i++) {
				reactions.set(i, backup.reactions.get(i).makeCopy());
			}
			count = backup.getNumberOfEvents();
			setNumberOfEvents(count);
			for (int i=0; i<count; i++) {
				events.set(i, backup.events.get(i).makeCopy());
			}
			setFunctionsMATLAB(backup.functionsMATLAB);
		} else {
			// Use backupSBMJ before altering the SBmodelJava within your code
			System.out.println("No backup has been made. Restore not possible!");
		}
	}

}
