package auxiliary.javamodel;

import auxiliary.javamodel.enums.SbmlType;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SBmodelTools {
	
	/**
	 * @param sbmj containing a SBmodel as Java Object
	 * This Method is used to add a standard compartment to a SBmodel because
	 * SBML has to consist of one compartment containig all the other stuff. 
	 */
	public static void addDefaultCompartment(SBmodelJava sbmj) {
		String compartment = "default";
		if (!existsName(sbmj, compartment)) {
			// create a new parameter which represents the default compartment
			// set its size to one and its type to SBML compartment
			sbmj.addParameter(compartment);
			int index = sbmj.getNumberOfParameters()-1;
			sbmj.getParameter(index).setValue(1.0);
			sbmj.getParameter(index).setType(SbmlType.COMPARTMENT);
			sbmj.getParameter(index).setCompartment("");
			// now check all SBmodel states, parameter and variables for
			// SBML species and compartment and add these to the default
			// compartment
			for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
				if (!sbmj.getParameter(i).getType().equals(SbmlType.PARAMETER))
					// the default compartment has to be the root compartment
					// therefor its compartment field has to be empty
					if (!sbmj.getParameter(i).getName().equals(compartment))
						if (sbmj.getParameter(i).getCompartment().equals(""))
							sbmj.getParameter(i).setCompartment(compartment);
			}
			for (int i=0; i<sbmj.getNumberOfStates(); i++) {
				if (!sbmj.getState(i).getType().equals(SbmlType.PARAMETER))
					if (sbmj.getState(i).getCompartment().equals(""))
						sbmj.getState(i).setCompartment(compartment);
			}
			for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
				if (!sbmj.getVariable(i).getType().equals(SbmlType.PARAMETER))
					if (sbmj.getVariable(i).getCompartment().equals(""))
						sbmj.getVariable(i).setCompartment(compartment);
			}
		}
	}
	
	public static String isLoopInCompartments(SBmodelJava sbmj) {
		String loopList = "";
		// fetch all defined compartment from given model
		List<Compartment> compartmentList = new LinkedList<Compartment>();
		for (int i=0; i<sbmj.getNumberOfStates(); i++) {
			if (sbmj.getState(i).getType().equals(SbmlType.COMPARTMENT)) {
				Compartment comp = new Compartment();
				comp.name = sbmj.getState(i).getName();
				comp.sbmodelIndex = i;
				comp.sbmodelKind = "state";
				comp.outsideCompartment = sbmj.getState(i).getCompartment();
				compartmentList.add(comp);
			}
		}
		for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
			if (sbmj.getParameter(i).getType().equals(SbmlType.COMPARTMENT)) {
				Compartment comp = new Compartment();
				comp.name = sbmj.getParameter(i).getName();
				comp.sbmodelIndex = i;
				comp.sbmodelKind = "parameter";
				comp.outsideCompartment = sbmj.getParameter(i).getCompartment();
				compartmentList.add(comp);
			}
		}
		for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
			if (sbmj.getVariable(i).getType().equals(SbmlType.COMPARTMENT)) {
				Compartment comp = new Compartment();
				comp.name = sbmj.getVariable(i).getName();
				comp.sbmodelIndex = i;
				comp.sbmodelKind = "variable";
				comp.outsideCompartment = sbmj.getVariable(i).getCompartment();
				compartmentList.add(comp);
			}
		}
		// perform test for each compartment wether the root 
		// compartment is reached
		List<Integer> passedCompartments = new LinkedList<Integer>();
		for (Compartment comp : compartmentList) {
			passedCompartments.clear();
			// if current compartment has empty compartment field
			// it has to be a root compartment -> nothing to do
			if (!comp.outsideCompartment.equals("")) {
				passedCompartments.add(compartmentList.indexOf(comp));
				// check wether we find a way to root compartment
				// for current compartment
				boolean way2root = existsWay2RootCompartment(comp.outsideCompartment, compartmentList, passedCompartments);
				// if there's no way to root compartment we have
				// discovered a loop -> construct string for warning dialog
				if (!way2root) {
					for (Integer index : passedCompartments) {
						if (!loopList.equals("")) loopList = loopList + " -> ";
						loopList = loopList + compartmentList.get(index).name + " (" +  
						compartmentList.get(index).sbmodelKind + " No. " + compartmentList.get(index).sbmodelIndex + 
						")";
					}
					break;
				}
			}
		}
		return loopList;
	}
	
	/**
	 * isValidName checks wether given name is SBmodel conform
	 * @param name String to check for SBmodel name compliance
	 * @return boolean value wether given name is an accepted SBmodel String 
	 */
	public static boolean isValidName(String name) {
		Pattern pattern = Pattern.compile("([A-Z]|[a-z]|_)+([A-Z]|[a-z]|[0-9]|_)*");
		Matcher matcher = pattern.matcher(name.trim());
		return matcher.matches(); 
	}
	
	/**
	 * existsName checks wether the given name is already in use
	 * in the given model 
	 * @param sbmj SBmodel Java object
	 * @param name name string
	 * @return boolean value true if name is already in use otherwise false
	 */
	public static boolean existsName(SBmodelJava sbmj, String name) {
		for (String usedName : getAllNames(sbmj)) {
			if (usedName.toLowerCase().equals(name.toLowerCase())) return true;
		}
		return false;
	}
	
	/**
	 * check wether all species in SBmodel Parameters are
	 * assigned to a compartment
	 * @param sbmj SBmodel Java object
	 * @return true if everything is fine
	 */
	public static boolean allSBmodelParametersWithinCompartments(SBmodelJava sbmj) {
		for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
			if (sbmj.getParameter(i).getType().equals(SbmlType.SPECIE)) {
				String compartment = sbmj.getParameter(i).getCompartment();
				if ((compartment==null) || compartment.equals("")) return false;
			}
		}
		return true;
	}
	/**
	 * check wether all species in SBmodel States are
	 * assigned to a compartment
	 * @param sbmj SBmodel Java object
	 * @return true if everything is fine
	 */
	public static boolean allSBmodelStatesWithinCompartments(SBmodelJava sbmj) {
		for (int i=0; i<sbmj.getNumberOfStates(); i++) {
			if (sbmj.getState(i).getType().equals(SbmlType.SPECIE)) {
				String compartment = sbmj.getState(i).getCompartment();
				if ((compartment==null) || compartment.equals("")) return false;
			}
		}
		return true;
	}
	
	/**
	 * check wether all species in SBmodel Variables are
	 * assigned to a compartment
	 * @param sbmj SBmodel Java object
	 * @return true if everything is fine
	 */
	public static boolean allSBmodelVariablesWithinCompartments(SBmodelJava sbmj) {
		for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
			if (sbmj.getVariable(i).getType().equals(SbmlType.SPECIE)) {
				String compartment = sbmj.getVariable(i).getCompartment();
				if ((compartment==null) || compartment.equals("")) return false;
			}
		}
		return true;
	}
	
	/**
	 * if a compartment is removed from given model check compartment
	 * fields from states, parameters, variables wether the removed
	 * compartment a used as outside compartment for another one
	 * @param sbmj SBmodel Java object
	 * @param compartment name of compartment removed from model
	 */
	public static void checkForRemovedCompartment(SBmodelJava sbmj, String compartment) {
		for (int i=0; i<sbmj.getNumberOfStates(); i++) {
			if ((sbmj.getState(i).getCompartment()!=null) && sbmj.getState(i).getCompartment().equals(compartment))
				sbmj.getState(i).setCompartment("");
		}
		for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
			if ((sbmj.getParameter(i).getCompartment()!=null) && sbmj.getParameter(i).getCompartment().equals(compartment))
				sbmj.getParameter(i).setCompartment("");
		}
		for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
			if ((sbmj.getVariable(i).getCompartment()!=null) && sbmj.getVariable(i).getCompartment().equals(compartment))
				sbmj.getVariable(i).setCompartment("");
		}
	}
	
	/**
	 * 
	 * @param sbmj
	 * @return number of compartments which are not assigned to other comparments
	 * (root compartments)
	 */
	public static int checkNumberOfRootCompartments(SBmodelJava sbmj) {
		int rootCompartmentsCount = 0;
		for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
			if (sbmj.getParameter(i).getType().equals(SbmlType.COMPARTMENT))
				if (sbmj.getParameter(i).getCompartment().equals("") || (sbmj.getParameter(i).getCompartment()==null))
					rootCompartmentsCount++;
		}
		for (int i=0; i<sbmj.getNumberOfStates(); i++) {
			if (sbmj.getState(i).getType().equals(SbmlType.COMPARTMENT))
				if (sbmj.getState(i).getCompartment().equals("") || (sbmj.getState(i).getCompartment()==null))
				rootCompartmentsCount++;
		}
		for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
			if (sbmj.getVariable(i).getType().equals(SbmlType.COMPARTMENT))
				if (sbmj.getVariable(i).getCompartment().equals("") || (sbmj.getVariable(i).getCompartment()==null))
				rootCompartmentsCount++;
		}
		return rootCompartmentsCount;
	}
	
	/**
	 * 
	 * @param sbmj SBmodel as Java Object
	 * @return list of Srings containing all used names within SBmodel
	 */
	private static List<String> getAllNames(SBmodelJava sbmj) {
		LinkedList<String> nameList = new LinkedList<String>();
		for (int i=0; i<sbmj.getNumberOfStates(); i++) {
			nameList.add(sbmj.getState(i).getName());
		}
		for (int i=0; i<sbmj.getNumberOfParameters(); i++) {
			nameList.add(sbmj.getParameter(i).getName());
		}
		for (int i=0; i<sbmj.getNumberOfVariables(); i++) {
			nameList.add(sbmj.getVariable(i).getName());
		}
		for (int i=0; i<sbmj.getNumberOfReactions(); i++) {
			nameList.add(sbmj.getReaction(i).getName());
		}
		for (int i=0; i<sbmj.getNumberOfEvents(); i++) {
			nameList.add(sbmj.getEvent(i).getName());
		}
		for (int i=0; i<sbmj.getNumberOfFunctions(); i++) {
			nameList.add(sbmj.getFunction(i).getName());
		}
		return nameList;
	}
	
	/**
	 * existsWay2RootCompartment tests recursive wether there exists a
	 * transitive connection to the root compartment for a given 
	 * compartment name
	 * @param compartmentName string with compartment name to start from
	 * @param compartmentList list of all defined compartments in model
	 * @param passedCompartments list of visited compartments on way to root
	 * @return true if no loop is found false otherwise
	 */
	private static boolean existsWay2RootCompartment(String compartmentName, List<Compartment> compartmentList, List<Integer> passedCompartments) {
		boolean way2root = false;
		int index = getCompartmentIndex(compartmentName, compartmentList);
		if (index<0) return false;
		if (passedCompartments.contains(index)) {
			passedCompartments.add(index);
			return false;
		} else {
			passedCompartments.add(index);
			if (compartmentList.get(index).outsideCompartment.equals("")) {
				way2root = true;
			} else {
				way2root = existsWay2RootCompartment(compartmentList.get(index).outsideCompartment, compartmentList, passedCompartments);
			}
		}
		return way2root;
	}
	
	/**
	 * getCompartmentIndex fetches Index for given
	 * compartment name in given compartment list 
	 */
	private static int getCompartmentIndex(String compartmentName, List<Compartment> compartmentList) {
		for (Compartment comp : compartmentList) {
			if (comp.name.equals(compartmentName))
				return compartmentList.indexOf(comp);
		}
		return -1;
	}

}

/*
 * helper class for routine that checks for loop
 * in compartment definitions
 */
class Compartment {
	public String name;
	public int sbmodelIndex;
	public String sbmodelKind;
	public String outsideCompartment;
}